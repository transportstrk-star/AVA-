# FleetShift — AVA Transport

Offline-first driver shift logger + admin control center.

**Version:** 1.6 (v1.5 + receipt upload on expenses)

## Location
```
/home/workdir/artifacts/fleet-app/
├── index.html            ← Combined launcher (Driver + Admin choice)
├── driver-app.html       ← Driver Portal only
├── admin-dashboard.html  ← Admin Control Center only
├── styles.css
├── app.js
└── README.md
```

## How to run
1. Prefer a local server (avoids `file://` fetch limits):
   ```bash
   cd fleet-app && npx serve .
   ```
   Then open the printed URL.
2. Or open `index.html` / `driver-app.html` directly in **Chrome, Edge, or Safari**.
3. Allow **camera** and **location** when the browser asks — required for watermarked photos and GPS stamps.
4. Works offline after the first load (assets cached by the browser).

---

## Features

### Driver Portal
- **PIN login** — select profile + enter 4–6 digit PIN
- **Forgot PIN?** — in-app guidance to request admin reset
- **Pre-Trip Check** — mandatory step after login, before any stage:
  - **Bus number** — auto-selected from the driver's profile, with a fleet dropdown and a **manual entry** fallback (manual entries are flagged to the admin)
  - **ODO meter before trip start** — validated as numeric and cannot be lower than the last reading recorded for that bus
  - The reading carries into Stage 1 (no double entry) and is shown as `ODO start` throughout the shift
- **Finish Shift** — close the shift at any time; the end-trip ODO reading is optional and distance is computed whenever both the start and end readings exist
- **All ODO readings optional** — start-trip and end-trip meters can both be left blank; a shift still opens, logs and closes cleanly with no distance shown
- **Extra trips with optional km** — start km and end km can be entered together, singly, or not at all
- **4-stage progressive shift workflow** (mandatory sequential stages):
  1. Before Trip Start — odometer + watermarked photo + GPS
  2. Reached Destination / Parking
  3. Before Return Trip Start
  4. Final Return Parking Completion
- Extra / inter-city trip logging
- Fuel & miscellaneous expenses (Calculation mode: Liters × Price, or Direct Entry)
- **Receipt upload** — attach a photo (camera) or PDF to any expense, optional; view, replace or remove it later, including on expenses saved before receipts existed
- History limited to a rolling **30-day** window (privacy isolation)
- Offline queue + auto-sync simulation (status badge)

### Admin Control Center
- Passcode: `admin123`
- Add / activate / deactivate drivers (with PIN assignment)
- Edit driver PINs from the roster
- **Reset PIN** — generates a new temporary 4-digit PIN and displays it for sharing with the driver
- Reassign bus numbers live
- Live uploads feed (trips, extras, expenses)
- Overview stats dashboard
- Master audit trail table

### PIN recovery
- Driver login has a **Forgot PIN?** link that explains how to get a reset from admin.
- Only admins can reset PINs (no self-service reset for security).

### Pre-seeded drivers
| Name              | ID       | Bus      | PIN  | Status  |
|-------------------|----------|----------|------|---------|
| Ahmed Al-Mansoori | DRV-1001 | DXB-4821 | 1001 | Active  |
| Mohammed Hassan   | DRV-1002 | SHJ-3190 | 1002 | Active  |
| Fatima Al-Kaabi   | DRV-1003 | AUH-7742 | 1003 | Active  |
| Rajesh Kumar      | DRV-1004 | DXB-5518 | 1004 | Locked  |

---

## Technical notes
- **Stack**: React 18 (CDN) + Tailwind CSS + Lucide icons
- **Storage**: `localStorage` (trips, drivers, expenses, offline queue)
- **Camera**: `getUserMedia` + canvas watermark (timestamp, driver, bus, GPS)
- **Network simulator**: toggle Online Sync ↔ Offline Mode; queued items flush when online
- Cloud sync to Google Sheets / Drive is **simulated** (console + status badge). Production would wire to Apps Script like the original AVA system.

## Limitations (prototype)
- Data lives in `localStorage` (clears if you clear site data).
- “Cloud sync” is simulated.
- Best on phone or with DevTools mobile emulation.
- Camera / GPS require HTTPS or localhost (`file://` may restrict permissions in some browsers).

---

Built as an evolution of the AVA Transport trip log system.

---

## Changelog — v1.2 (bug-fix pass)

| # | Area | Issue found in v1.1 | Fix |
|---|------|---------------------|-----|
| 1 | Shift workflow | Saving the 4th stage flipped the screen straight back to the empty "Ready for shift?" card, so the just-finished shift's readings vanished with no completion confirmation — and the "Shift Complete" card further down the stage list was unreachable dead code (the same `completed` condition was tested twice, in opposite branches). | Completed state is now its own screen: confirmation + all 4 odometer readings + total shift distance + a "Start New Shift" button. Dead branch removed. |
| 2 | Completed-shift summary | No total distance was ever shown for a shift. | New `shiftDistance()` helper = final odometer − start odometer, displayed on the completion card. |
| 3 | Odometer integrity | Any number could be entered for stages 2–4 — a driver could type a *lower* reading than the previous stage and the log accepted it. | Stages 2–4 now reject an odometer below the previous stage's reading, with an inline error message. |
| 4 | Offline sync queue | Auto-sync never fired for a freshly logged item: `enqueue()` calls `flushQueue()` from the same render closure, where `queue` is still the pre-append array, so the `queue.length === 0` guard returned immediately and the item sat unsynced until the driver toggled Offline→Online. The flush also ended with `setQueue([])` / `saveQueue([])`, wiping anything logged during the ~1 s simulated upload. | `flushQueue(items)` takes the fresh batch explicitly and removes only the ids it actually sent, so items logged mid-flush survive. |
| 5 | Expenses / audit | `ex.amount.toFixed(2)` and `item.amount` were assumed to be numbers; a legacy or hand-edited `localStorage` value (string/absent) crashed the Expenses tab and the Audit table. | Coerced with `Number(x || 0)` in both render paths. |
| 6 | Login | `state.drivers.filter(...)` ran unguarded — a partially-written `localStorage` payload with no `drivers` array threw a white screen on load. | Guarded with `(state.drivers || [])`. |

### How it was verified
`app.js` was transpiled with Babel (`preset-react`) and every screen was rendered head-lessly with `react-dom/server` against seeded state:
login (combined / driver-only / admin-only), driver shift (no shift / 2-of-4 in progress / completed), driver history, extras, expenses, admin overview, roster, audit and buses — **21/21 assertions passed**, including the new distance calculation and the completed-state navigation.

> Note: this pass is a static + server-render review. Camera/GPS capture, `getUserMedia`, and the real `localStorage` network-flush timing still need a run on an actual device or browser.

---

## Changelog — v1.3 (pre-trip ODO + bus selection)

*See also the v1.4 section below.*

Flow now is: **PIN login → Pre-Trip Check (bus + optional start ODO) → deploy → Finish Shift (optional end ODO)**.

Every ODO reading is **optional**. The app never refuses a shift, an extra trip or a close because a meter reading is missing — it records the readings that exist and shows "—" where a distance cannot be computed.

| # | Area | v1.2 behaviour | v1.3 behaviour |
|---|------|----------------|----------------|
| 1 | Shift start | "Start New Shift" created the trip **immediately** using `driver.bus` — the driver never entered a starting ODO, so the first stage's reading was the only "start" value and there was no way to prove where the shift began. | "Start New Shift" opens a **Pre-Trip Check** card. The trip record is only created once a bus and a pre-trip ODO are supplied. |
| 2 | Bus number | Fixed to `driver.bus` for the whole shift; a driver swapping to another vehicle had no route to record it (admin had to reassign the bus first). | **Auto-selected** from the profile into a dropdown of the fleet list, plus **Manual entry…** to type an unlisted bus. Each trip stores `bus`, `busSource: 'auto' | 'manual'` and `assignedBus`, so the admin can see the driver departed from their assigned vehicle. |
| 3 | ODO validation | First stage accepted any number. | Pre-trip ODO is required, numeric, and cannot be below **the highest reading ever recorded for that bus** (`lastOdometerForBus()` — scans pre-trip values and all four stages, case/space-insensitive). The card previews the last known reading before the driver submits. |
| 4 | Data model | `{ id, driverId, driverName, bus, status, stages, createdAt, completedAt }` | Adds `startOdometer`, `busSource`, `assignedBus`. `enqueue({ type: 'trip_start' })` pushes the departure record into the offline queue, so the pre-trip reading syncs like every other event. |
| 5 | Stage 1 | Free numeric input. | Prefilled from the pre-trip ODO, with the floor enforced again in `openCameraForStage()` — a driver cannot photograph a lower reading than they declared at departure. |
| 6 | Header / summary | Always showed `driver.bus`. | Header and completion summary show the **bus actually used**, with an amber `(manual)` / `MANUAL` flag when it differs from the assignment. |
| 7 | Admin audit | `${n}/4 stages`. | `2/4 stages · ODO start 124,580 km · manual bus` — departure reading and bus source are visible in the Live Upload Feed and the Master Audit Trail. |

### Verification
Babel-transpiled and rendered with `react-dom/server` against seeded state — **22/22 assertions passed**, including:

- the pre-trip screen renders `Pre-Trip Check`, `Bus number`, `AUTO-SELECTED`, `assigned to you`, `Manual entry…`, `ODO meter before trip start`, `Start Shift`
- the last-ODO hint reads the seeded trip: `Last recorded for DXB-4821: 124,712 km`
- a driver with **no assigned bus** still gets a usable screen (`No bus assigned to your profile…`)
- a manual-bus trip is flagged in both the header and the pre-trip strip
- `lastOdometerForBus()` — highest across stages, includes pre-trip values, case/space-insensitive, returns `null` for unknown or empty bus
- Stage 1 displays `Pre-trip ODO: 124,580 km`
- admin audit shows `ODO start 124,580 km` and `manual bus`
- all v1.2 regressions still pass (completed-state summary, shift distance, offline queue, expense formatting, roster, audit, login)

> Still device-only: camera capture, GPS stamping and the live sync timing. The pre-trip form itself is pure state + validation and is covered by the render tests.

---

## Changelog — v1.4 (finish shift by end-trip ODO)

A shift can now be **closed by entering the odometer reading at the end of the trip**, instead of being locked into the 4-stage sequence.

| # | Area | v1.3 behaviour | v1.4 behaviour |
|---|------|----------------|----------------|
| 1 | Closing a shift | The only exit was recording all four stages; the last stage's odometer doubled as the end reading. A driver who skipped a stage could not close the shift at all. | A **Finish Shift** card sits in the live shift view from the moment the shift starts. Tapping it opens an **End of Trip** form that asks for the ODO meter reading; "Confirm End & Close Shift" writes the reading, the end time, and closes the shift. |
| 2 | Validation | Stage-level only. | End ODO must be numeric, non-negative, and **≥ the highest reading already recorded in this shift** (`shiftFloor` = max of the pre-trip ODO and every saved stage). Two distinct messages: *"End ODO must be at least 124,580 km (shift start)"* when it dips below the departure reading, and *"…124,655 km (highest reading this shift)"* when it dips below a later stage. The confirm button stays disabled until the value passes. |
| 3 | Live feedback | n/a | The form shows `Started at`, `Highest reading so far`, a live **Distance for this shift** preview as the driver types, and an amber warning counting the stages still unrecorded. |
| 4 | Data model | `startOdometer`, `bus`, `busSource`, `assignedBus`, `stages` | Adds `endOdometer`, `endedAt`, `closedBy: 'end_odo'`, `closedEarly`. A new `trip_end` event joins `trip_start` in the offline sync queue. |
| 5 | Distance | `final stage − start stage` | `endOdometer − startOdometer`, falling back to stage readings for trips closed the old way — so v1.2/v1.3 records still report correctly. A 2-of-4 shift closed at 124,712 km now reports its true 132 km instead of nothing. |
| 6 | Completion summary | Bus, start ODO, four stage rows, distance. | Three-up **ODO start / ODO end / Distance** panel, the stage rows kept for audit, and *"Closed with 2 of 4 stages recorded"* when the shift was sealed early. |
| 7 | Admin | `n/4 stages · ODO start …` | `2/4 stages · ODO start 124,580 km → end 124,712 km · 132 km · partial log` in the Live Upload Feed and Master Audit Trail. |
| 8 | Offline queue | Two events enqueued in the same render overwrote each other (the `queue` prop was stale). | `enqueue()` bases its new array on the persisted queue when it is longer than the render-time one, so `trip_start` + `trip_end` both survive. |

### Verification — full end-to-end in a real DOM

`app.js` transpiled with Babel and mounted in **jsdom** with live React state; clicks and typing dispatched as real DOM events, then `localStorage` inspected directly. **43/43 assertions passed.**

| Test | Result |
|---|---|
| Pre-trip: bus auto-selected from profile, Start disabled until ODO typed, then starts | ✅ select value `DXB-4821`; CTA disabled → enabled |
| **Finish with a valid end ODO** | ✅ preview `Distance for this shift: 132 km`; confirm enabled; click closes the shift |
| Persisted record after close | ✅ `status: completed`, `startOdometer: 124580`, `endOdometer: 124712`, `closedBy: end_odo`, `endedAt` set, `closedEarly: true` |
| Offline queue after close | ✅ `trip_start, trip_end` both present |
| **End ODO below start rejected** | ✅ confirm disabled, inline *"End ODO cannot be below 124,600 km."*, shift stays open |
| **End ODO below a later stage rejected** | ✅ message cites *124,655 km (highest reading this shift)*, not the start |
| Valid reading after rejection | ✅ confirm re-enabled, closes with *"Closed with 2 of 4 stages"*, stage data preserved |
| Manual bus entry | ✅ `dxb-6600` upper-cased, carried into the shift, `MANUAL` flag shown |
| Admin reporting | ✅ `ODO start 124,580 km → end 124,712 km · 132 km · partial log` |

The v1.3 render suite was re-run unchanged — **22/22 assertions still pass**, so the pre-trip screen, last-ODO hint, no-bus fallback and v1.2 regressions are intact.

> Camera capture, GPS stamping and real network sync still require a device over HTTPS; the end-ODO flow is pure state + validation and is fully covered above.

---

## Changelog — v1.5 (optional ODO / optional extra-trip km)

Every odometer field became optional. Nothing in the app now blocks a shift, an extra trip, or a close because a reading is missing — it stores what exists and renders `—` where a distance cannot be derived.

### What was required → what is now optional

| # | Field | v1.4 | v1.5 |
|---|-------|------|------|
| 1 | **Start-trip ODO** (Pre-Trip Check) | Required. Blank → *"Enter the ODO meter reading before trip start"*, and the Start button stayed disabled until a value was typed. | Optional. The Start button is enabled as soon as a bus is chosen. Blank stores `startOdometer: null`, the toast reads *"Shift started · DXB-4821 (no ODO)"*, and Stage 1 stays empty instead of being prefilled. The card says *"Leave blank if the meter cannot be read — the shift still starts."* |
| 2 | **End-trip ODO** (Finish Shift) | Required. Blank → *"Enter the end-trip ODO reading"*; confirm was disabled. | Optional. Confirm is enabled immediately; a blank close stores `endOdometer: null` and `closedBy: 'no_odo'`, with the toast *"Shift closed (no end ODO)"* and the hint *"Leave blank to close without an end reading."* |
| 3 | **Extra trip — start km** | Required, and a `0` reading was treated as invalid because the check used `!start`. | Fully optional. Blank stores `startKm: null`. A typed value must be a number and not negative. |
| 4 | **Extra trip — end km** | Required, and `end < start` blocked the whole entry. | Fully optional. Blank stores `endKm: null`. The `end < start` sanity check now runs **only when both values are present**. |
| 5 | **Extra trip distance** | `end - start`, always computed — so a blank pair produced `NaN` or `0 km`. | `null` unless both readings exist. The list shows `— → —` plus *"no km reading"*, and a live *"Distance 132 km"* preview appears in the form as both fields fill. |
| 6 | **Shift distance** | `final − start`, or nothing. | `startOdometer → endOdometer` when both exist; falls back to stage readings for older records; `null` (rendered as `—`) otherwise. Never `NaN`, never a fake `0`. |
| 7 | **Admin feed / audit** | `${e.distance} km` — printed `null km` / `NaN km` for missing values. | `50 km` when known, *"no km reading"* when absent; shifts read `ODO start 124,580 km → end 124,712 km · 132 km` and omit the segment entirely when a reading is missing. |

### Null-safety pass

`shiftDistance()` now returns `null` for any missing/invalid endpoint (including `undefined` trips). `lastOdometerForBus()` ignores `null` readings, so the "last recorded" hint and its floor check simply do not fire when a bus has no history. Every render path that prints a km value guards against `null` first, so the UI shows `—` rather than `NaN`, `0 km`, or `null km`.

Legacy records written by v1.2–v1.4 — which always had numbers — still display exactly as before; the `endOdometer`/`startOdometer` fallbacks to stage readings keep their distances intact.

> **Storage note:** this prototype persists to `localStorage`, so there is no schema migration and no NOT NULL constraint to relax — a missing reading is simply `null` in the trip or extra object. If this is ever wired to the Apps Script / Google Sheets backend the README describes, the ODO columns must be made nullable there too; the client already sends `null` and never invents a placeholder value.

### Verification — 4 required cases plus regression, all end-to-end in jsdom

Real DOM clicks and keystrokes against live React state, with `localStorage` read back afterwards. **143 assertions across four suites, 0 failures.**

| Case | Result |
|---|---|
| **Shift with BOTH ODO blank** | ✅ Start enabled with blank ODO → shift opens; `ODO start —` in the strip; Finish confirm enabled with blank input; **shift closes with no error**; stored `startOdometer: null`, `endOdometer: null`, `closedBy: 'no_odo'`, `status: 'completed'`; summary distance shows `—`, no `NaN` |
| **Start only** | ✅ `startOdometer: 124580`, `endOdometer: null`, distance `null` → `—` |
| **End only** | ✅ `startOdometer: null`, `endOdometer: 124712`, `closedBy: 'end_odo'`, distance `null` → `—` |
| **Both** | ✅ `124580 → 124712`, distance **132 km** shown in the summary |
| Both present, end < start | ✅ confirm disabled, *"End ODO cannot be below 124,600 km"*, shift stays open |
| Extra trip: both blank / start only / end only | ✅ `startKm: null` / `endKm: null` / `distance: null`; list renders `— → —` and *"no km reading"*, no `NaN` |
| Extra trip: both entered | ✅ live preview `Distance 132 km`, stored `distance: 132` |
| Extra trip: both present but reversed | ✅ rejected with *"End km cannot be lower than start km"*, nothing saved |
| Extra trip: note only | ✅ saves with `distance: null` |
| Admin feed with null + legacy distances | ✅ *"no km reading"* for the null one, `50 km` preserved for the legacy one, no `NaN` |
| v1.4 regressions (43) + v1.3 render suite (22) | ✅ all still pass |

> Camera capture, GPS stamping and real network sync still require a device over HTTPS. Everything else above was exercised in a real DOM.

---

## Changelog — v1.6 (receipt upload on expenses)

Expenses can carry a **photo or PDF receipt**. Entirely optional — an expense with no receipt saves exactly as before.

### How it works

| Step | Behaviour |
|---|---|
| **Attach** | Two buttons in the expense form: **Take photo** (opens the phone camera via `capture="environment"`) and **Upload file**. Both use `accept="image/*,application/pdf"`. |
| **Preview** | Once picked, the form shows a thumbnail, the file name, and *Photo/PDF · size*. The CTA changes to **Save Expense + Receipt**. |
| **Save** | The receipt is stored on the expense record as `expense.receipt = { dataUrl, name, type, size, addedAt }` and persisted to `localStorage` like everything else in this app. |
| **List** | Each expense with a receipt shows a thumbnail (tap to open) plus **View receipt**, and **Replace** / **Remove** actions. |
| **Viewer** | Full-screen modal: image shown inline, PDF shown as a card with an **Open PDF** link; header carries the file name, expense type, amount and size. |
| **Replace / Remove** | Both available from the list row and from inside the viewer. |
| **Older expenses** | Expenses saved by v1.2–v1.5 have no `receipt` field at all. They render *"No receipt attached"* with an **Attach** button, so a receipt can be back-filled later. |

### Size and storage handling

| Guard | Value |
|---|---|
| Max picked file | **5 MB** — larger files are refused with *"Receipt is 6.0 MB — the limit is 5.0 MB"* |
| Accepted types | any `image/*` or `application/pdf`; anything else → *"Attach a photo or a PDF"* |
| Image compression | photos are downscaled and re-encoded on a canvas through three passes — 1400px @ 0.82, 1200px @ 0.65, 1000px @ 0.5 — stopping as soon as the payload fits the ~1.2 M-char storage budget |
| No-canvas fallback | if the canvas API is unavailable the original data URL is kept rather than failing |
| Quota handling | `saveState()` now returns `false` instead of throwing when `localStorage` is full, and the driver sees *"Storage full — remove a receipt or attach a smaller photo"*. Nothing is written in that case. |
| Sync queue | the base64 blob is **never** put in the offline queue — only `receiptMeta: { name, type, size }` travels with the `expense` event |

Admin side: an expense with a receipt is marked with a paperclip in the Live Upload Feed and reads `142.50 AED · receipt` in the Master Audit Trail.

### Verification — 52 assertions on the receipt path, all passing

Real DOM in jsdom: files pushed through the actual `change` handler, results read back from `localStorage`.

| Test | Result |
|---|---|
| Conversion guards | image → receipt object with `data:image/png`; PDF accepted; 6 MB file refused with the limit message; `text/plain` refused with *"Attach a photo or a PDF"* |
| `formatBytes` | `2048 → 2 KB`, `3145728 → 3.0 MB` |
| Form UI | Receipt labelled optional; Take photo + Upload file present; 5 MB copy shown; **two** hidden inputs (`capture="environment"` on one); both carry `accept="image/*,application/pdf"`; Save enabled with no receipt |
| Save with receipt | draft preview appears, CTA becomes *Save Expense + Receipt*, expense stores `receipt.dataUrl` + name, list shows *View receipt* and a thumbnail |
| Queue payload | `data:image` **absent** from the queued event; `receiptMeta.name` present |
| **Reload** | fresh component tree loaded from stored state still shows *View receipt*, the thumbnail's `src` **is the stored data URL**, and the viewer opens with the correct file name, Replace and Remove |
| Replace | receipt swapped to `new-receipt.png`, new size stored, still exactly **one** expense (no duplicate) |
| Remove | `receipt` set back to `null`, the expense and its 142.50 amount untouched, row falls back to *No receipt attached* |
| Legacy back-fill | a v1.5-era expense with no `receipt` field renders, offers **Attach**, gains a receipt, and keeps its original 114 amount |
| Admin feed | `142.50 AED · receipt` when attached, plain when not, no `NaN` |
| Quota failure | toast *"Storage full…"* shown and **nothing persisted** |

The four earlier suites were re-run unchanged and still pass: **43** (shift/ODO end-to-end), **40** (optional-ODO cases), **38** (optional extra-trip km), **22** (render suite).

> One real defect was caught here and fixed: attach/replace on an already-saved expense read the target id from render-time state, which was `null` in the closure that handled the file. The target is now held in a ref, so it is read synchronously at pick time.
>
> Camera capture itself and the canvas compression pass still need a device over HTTPS — jsdom has no canvas, so the fallback path is what the tests exercised. Everything else above ran for real.
