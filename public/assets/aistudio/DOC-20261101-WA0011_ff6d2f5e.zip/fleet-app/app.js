const { useState, useEffect, useRef, useCallback, useMemo } = React;

// ─────────────────────────────────────────────
// Constants & Seed Data
// ─────────────────────────────────────────────
const ADMIN_PASS = 'admin123';
const STORAGE_KEY = 'fleetshift_v1';
const QUEUE_KEY = 'fleetshift_queue_v1';

const SEED_DRIVERS = [
  { id: 'DRV-1001', name: 'Ahmed Al-Mansoori', bus: 'DXB-4821', phone: '+971501234001', pin: '1001', status: 'active' },
  { id: 'DRV-1002', name: 'Mohammed Hassan', bus: 'SHJ-3190', phone: '+971501234002', pin: '1002', status: 'active' },
  { id: 'DRV-1003', name: 'Fatima Al-Kaabi', bus: 'AUH-7742', phone: '+971501234003', pin: '1003', status: 'active' },
  { id: 'DRV-1004', name: 'Rajesh Kumar', bus: 'DXB-5518', phone: '+971501234004', pin: '1004', status: 'locked' },
];

const STAGES = [
  { id: 1, key: 'start', title: 'Before Trip Start', subtitle: 'Record starting odometer & photo', icon: 'Play' },
  { id: 2, key: 'dest', title: 'Reached Destination', subtitle: 'Arrival / parking odometer', icon: 'MapPin' },
  { id: 3, key: 'returnStart', title: 'Before Return Start', subtitle: 'Odometer before return leg', icon: 'RotateCcw' },
  { id: 4, key: 'final', title: 'Final Return Parking', subtitle: 'Complete shift & sync', icon: 'Flag' },
];

// ─────────────────────────────────────────────
// Storage helpers
// ─────────────────────────────────────────────
function loadState() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      // Migrate: ensure every driver has a pin
      if (parsed.drivers) {
        parsed.drivers = parsed.drivers.map(d => ({
          ...d,
          pin: d.pin || (d.id && d.id.replace(/\D/g, '').slice(-4)) || '0000',
        }));
      }
      return parsed;
    }
  } catch (e) {}
  return {
    drivers: SEED_DRIVERS,
    trips: [],
    extras: [],
    expenses: [],
    buses: ['DXB-4821', 'SHJ-3190', 'AUH-7742', 'DXB-5518', 'DXB-2201', 'AUH-8800'],
  };
}

function saveState(state) {
  // Receipts are stored as data URLs, so localStorage can genuinely run out of room.
  // Return false instead of throwing so the caller can warn the driver.
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    return true;
  } catch (e) {
    return false;
  }
}

function loadQueue() {
  try {
    return JSON.parse(localStorage.getItem(QUEUE_KEY) || '[]');
  } catch {
    return [];
  }
}

function saveQueue(q) {
  localStorage.setItem(QUEUE_KEY, JSON.stringify(q));
}

// ─────────────────────────────────────────────
// Utils
// ─────────────────────────────────────────────
function uid(prefix = 'ID') {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
}

function formatDate(ts) {
  if (!ts) return '—';
  const d = new Date(ts);
  return d.toLocaleString('en-AE', {
    day: '2-digit', month: 'short', year: 'numeric',
    hour: '2-digit', minute: '2-digit', hour12: false,
  });
}

function formatKm(n) {
  if (n == null || n === '') return '—';
  return Number(n).toLocaleString('en') + ' km';
}

function daysAgo(ts) {
  return (Date.now() - ts) / (1000 * 60 * 60 * 24);
}

// Distance covered by a shift: pre-trip ODO (or stage 1) → end-trip ODO (or the final stage)
function shiftDistance(trip) {
  if (!trip) return null;
  const s = trip.stages || {};
  const first = trip.startOdometer != null
    ? Number(trip.startOdometer)
    : (s.start ? Number(s.start.odometer) : null);
  const last = trip.endOdometer != null
    ? Number(trip.endOdometer)
    : (s.final ? Number(s.final.odometer) : null);
  if (first == null || last == null || isNaN(first) || isNaN(last)) return null;
  return Math.max(0, last - first);
}

// ── Receipt attachments ─────────────────────────────
const RECEIPT_MAX_BYTES = 5 * 1024 * 1024;        // hard cap on the picked file
const RECEIPT_MAX_CHARS = 1200000;                // cap on the stored base64 payload
const RECEIPT_ACCEPT = 'image/*,application/pdf';

function formatBytes(n) {
  if (n == null) return '—';
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

function readFileAsDataUrl(file) {
  return new Promise((resolve, reject) => {
    try {
      const fr = new FileReader();
      fr.onload = () => resolve(String(fr.result || ''));
      fr.onerror = () => reject(fr.error || new Error('Could not read the file'));
      fr.readAsDataURL(file);
    } catch (e) {
      reject(e);
    }
  });
}

function canvasUsable() {
  try {
    const c = document.createElement('canvas');
    return !!(c.getContext && c.getContext('2d') && c.toDataURL);
  } catch (e) {
    return false;
  }
}

// Downscale + re-compress a photo so a receipt fits in localStorage.
// Falls back to the untouched data URL when canvas is unavailable.
function shrinkImage(dataUrl, maxDim = 1400, quality = 0.82) {
  return new Promise((resolve) => {
    if (!canvasUsable()) return resolve(dataUrl);
    let settled = false;
    const finish = (v) => { if (!settled) { settled = true; resolve(v); } };
    setTimeout(() => finish(dataUrl), 1500);
    try {
      const img = new Image();
      img.onload = () => {
        try {
          const scale = Math.min(1, maxDim / Math.max(img.width || maxDim, img.height || maxDim));
          const canvas = document.createElement('canvas');
          canvas.width = Math.max(1, Math.round((img.width || maxDim) * scale));
          canvas.height = Math.max(1, Math.round((img.height || maxDim) * scale));
          const ctx = canvas.getContext('2d');
          if (!ctx) return finish(dataUrl);
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          finish(canvas.toDataURL('image/jpeg', quality));
        } catch (e) {
          finish(dataUrl);
        }
      };
      img.onerror = () => finish(dataUrl);
      img.src = dataUrl;
    } catch (e) {
      finish(dataUrl);
    }
  });
}

async function fileToReceipt(file) {
  const name = file.name || 'receipt';
  const type = file.type || '';
  const size = file.size || 0;

  if (!file) throw new Error('No file selected');
  if (size > RECEIPT_MAX_BYTES) {
    throw new Error(`Receipt is ${formatBytes(size)} — the limit is ${formatBytes(RECEIPT_MAX_BYTES)}`);
  }
  const isImage = type.startsWith('image/');
  const isPdf = type === 'application/pdf';
  if (!isImage && !isPdf) {
    throw new Error('Attach a photo or a PDF');
  }

  let dataUrl = await readFileAsDataUrl(file);

  if (isImage) {
    // Try progressively stronger compression until it fits the storage budget
    for (const [dim, q] of [[1400, 0.82], [1200, 0.65], [1000, 0.5]]) {
      const candidate = await shrinkImage(dataUrl, dim, q);
      dataUrl = candidate;
      if (dataUrl.length <= RECEIPT_MAX_CHARS) break;
    }
  }

  if (dataUrl.length > RECEIPT_MAX_CHARS * 1.6) {
    throw new Error('Receipt is too large to store — try a smaller photo');
  }

  return { dataUrl, name, type: isPdf ? 'application/pdf' : (type || 'image/*'), size, addedAt: Date.now() };
}

// Highest odometer ever recorded for a bus (pre-trip readings + all 4 stages)
function lastOdometerForBus(state, bus) {
  if (!bus) return null;
  const target = String(bus).trim().toUpperCase();
  let last = null;
  ((state && state.trips) || []).forEach(t => {
    if (String(t.bus || '').trim().toUpperCase() !== target) return;
    const nums = [];
    if (t.startOdometer != null) nums.push(Number(t.startOdometer));
    if (t.endOdometer != null) nums.push(Number(t.endOdometer));
    Object.values(t.stages || {}).forEach(st => {
      if (st && st.odometer != null) nums.push(Number(st.odometer));
    });
    nums.forEach(n => {
      if (!isNaN(n) && (last == null || n > last)) last = n;
    });
  });
  return last;
}

function Icon({ name, size = 20, className = '' }) {
  const ref = useRef(null);
  useEffect(() => {
    if (ref.current && window.lucide) {
      ref.current.innerHTML = '';
      const icon = lucide.createElement(lucide.icons[name] || lucide.icons.Circle);
      icon.setAttribute('width', size);
      icon.setAttribute('height', size);
      icon.setAttribute('stroke-width', '2');
      ref.current.appendChild(icon);
    }
  }, [name, size]);
  return <span ref={ref} className={`inline-flex items-center justify-center ${className}`} />;
}

// ─────────────────────────────────────────────
// Watermarked Camera Component
// ─────────────────────────────────────────────
function WatermarkCamera({ driver, bus, onCapture, onCancel }) {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const streamRef = useRef(null);
  const [ready, setReady] = useState(false);
  const [error, setError] = useState(null);
  const [gps, setGps] = useState(null);
  const [capturing, setCapturing] = useState(false);

  useEffect(() => {
    let mounted = true;
    async function start() {
      try {
        // GPS
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (pos) => {
              if (mounted) setGps({
                lat: pos.coords.latitude.toFixed(5),
                lng: pos.coords.longitude.toFixed(5),
              });
            },
            () => { if (mounted) setGps({ lat: 'N/A', lng: 'N/A' }); },
            { enableHighAccuracy: true, timeout: 8000 }
          );
        } else {
          setGps({ lat: 'N/A', lng: 'N/A' });
        }

        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
          audio: false,
        });
        if (!mounted) {
          stream.getTracks().forEach(t => t.stop());
          return;
        }
        streamRef.current = stream;
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
          await videoRef.current.play();
          setReady(true);
        }
      } catch (err) {
        setError(err.message || 'Camera access denied');
      }
    }
    start();
    return () => {
      mounted = false;
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(t => t.stop());
      }
    };
  }, []);

  const capture = async () => {
    if (!videoRef.current || !canvasRef.current || !ready) return;
    setCapturing(true);
    const video = videoRef.current;
    const canvas = canvasRef.current;
    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    const ctx = canvas.getContext('2d');
    ctx.drawImage(video, 0, 0);

    // Watermark badge
    const pad = 12;
    const lineH = 16;
    const lines = [
      `⏱ ${new Date().toLocaleString('en-AE', { hour12: false })}`,
      `👤 ${driver.name} (${driver.id})`,
      `🚌 ${bus}`,
      `📍 ${gps ? `${gps.lat}, ${gps.lng}` : 'GPS…'}`,
    ];
    const boxH = lines.length * lineH + pad * 2;
    const boxW = Math.min(canvas.width - 16, 340);
    const x = 8;
    const y = canvas.height - boxH - 8;

    ctx.fillStyle = 'rgba(0,0,0,0.78)';
    ctx.beginPath();
    ctx.roundRect(x, y, boxW, boxH, 8);
    ctx.fill();

    ctx.fillStyle = '#ffffff';
    ctx.font = 'bold 13px ui-monospace, monospace';
    lines.forEach((line, i) => {
      ctx.fillText(line, x + pad, y + pad + (i + 0.8) * lineH);
    });

    // Accent stripe
    ctx.fillStyle = '#0ea5e9';
    ctx.fillRect(x, y, 4, boxH);

    const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(t => t.stop());
    }
    setCapturing(false);
    onCapture({ dataUrl, gps, timestamp: Date.now() });
  };

  return (
    <div className="fixed inset-0 z-50 flex flex-col bg-black">
      <div className="flex items-center justify-between p-3 bg-slate-900/90">
        <button onClick={onCancel} className="text-slate-300 text-sm flex items-center gap-1">
          <Icon name="X" size={18} /> Cancel
        </button>
        <span className="text-xs text-slate-400 font-medium">Watermarked Proof</span>
        <div className="w-16" />
      </div>

      <div className="flex-1 relative flex items-center justify-center overflow-hidden">
        {error ? (
          <div className="text-center p-6">
            <Icon name="CameraOff" size={48} className="text-red-400 mb-3" />
            <p className="text-red-300 text-sm mb-4">{error}</p>
            <p className="text-slate-500 text-xs">Allow camera permission and try again.</p>
            <button onClick={onCancel} className="mt-4 px-4 py-2 bg-slate-800 rounded-lg text-sm">Close</button>
          </div>
        ) : (
          <>
            <video ref={videoRef} playsInline muted className="max-w-full max-h-full object-contain" />
            <canvas ref={canvasRef} className="hidden" />
            {ready && (
              <div className="absolute bottom-4 left-3 right-3 pointer-events-none">
                <div className="bg-black/70 text-white text-[10px] font-mono p-2 rounded-lg leading-relaxed border-l-4 border-sky-500">
                  <div>⏱ {new Date().toLocaleString('en-AE', { hour12: false })}</div>
                  <div>👤 {driver.name} ({driver.id})</div>
                  <div>🚌 {bus}</div>
                  <div>📍 {gps ? `${gps.lat}, ${gps.lng}` : 'Acquiring GPS…'}</div>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {!error && (
        <div className="p-4 bg-slate-900/95 safe-bottom">
          <button
            onClick={capture}
            disabled={!ready || capturing}
            className="w-full py-4 rounded-2xl bg-sky-500 hover:bg-sky-400 disabled:opacity-50 text-white font-semibold text-lg flex items-center justify-center gap-2"
          >
            <Icon name="Camera" size={22} />
            {capturing ? 'Processing…' : 'Capture Proof'}
          </button>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Network Simulator Badge
// ─────────────────────────────────────────────
function NetworkBadge({ online, syncing, queueLen, onToggle }) {
  let cls = online ? 'status-online' : 'status-offline';
  let label = online ? 'Online Sync' : 'Offline Mode';
  let icon = online ? 'Wifi' : 'WifiOff';
  if (syncing) {
    cls = 'status-syncing';
    label = 'Syncing…';
    icon = 'RefreshCw';
  }
  return (
    <button onClick={onToggle} className={`status-badge ${cls}`} title="Click to toggle network simulation">
      <Icon name={icon} size={12} />
      {label}
      {queueLen > 0 && (
        <span className="ml-1 bg-black/30 px-1.5 rounded-full text-[10px]">{queueLen}</span>
      )}
    </button>
  );
}

// ─────────────────────────────────────────────
// Driver Portal
// ─────────────────────────────────────────────
function DriverPortal({ state, setState, driver, online, setOnline, queue, setQueue, onLogout }) {
  const [tab, setTab] = useState('shift'); // shift | extras | expenses | history
  const [activeTrip, setActiveTrip] = useState(null);
  const [cameraOpen, setCameraOpen] = useState(null); // stage key or null
  const [odometerInput, setOdometerInput] = useState('');
  // Pre-trip check: bus number + ODO meter before trip start
  const [setupBus, setSetupBus] = useState(driver.bus || '');
  const [setupBusManual, setSetupBusManual] = useState(false);
  const [setupOdo, setSetupOdo] = useState('');
  const [setupMode, setSetupMode] = useState(false); // pre-trip form forced open (after a completed shift)
  const [finishMode, setFinishMode] = useState(false); // end-trip ODO form open
  const [endOdo, setEndOdo] = useState('');
  const [syncing, setSyncing] = useState(false);
  const [toast, setToast] = useState(null);

  // Extra trip form
  const [extraForm, setExtraForm] = useState({ startKm: '', endKm: '', note: '', time: '' });
  // Expense form
  const [expMode, setExpMode] = useState('calc'); // calc | direct
  const [expForm, setExpForm] = useState({ liters: '', price: '2.85', total: '', note: '', type: 'fuel' });
  // Receipt attachment for the expense being written (optional)
  const [receiptDraft, setReceiptDraft] = useState(null);   // { dataUrl, name, type, size, addedAt }
  const [receiptBusy, setReceiptBusy] = useState(false);
  const receiptTargetRef = useRef(null); // null | expense id being replaced (ref = synchronous)
  const [viewReceipt, setViewReceipt] = useState(null);     // expense object being previewed
  const receiptCamRef = useRef(null);
  const receiptFileRef = useRef(null);

  const myTrips = useMemo(() => {
    return (state.trips || [])
      .filter(t => t.driverId === driver.id && daysAgo(t.createdAt) <= 30)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [state.trips, driver.id]);

  const myExtras = useMemo(() => {
    return (state.extras || [])
      .filter(e => e.driverId === driver.id && daysAgo(e.createdAt) <= 30)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [state.extras, driver.id]);

  const myExpenses = useMemo(() => {
    return (state.expenses || [])
      .filter(e => e.driverId === driver.id && daysAgo(e.createdAt) <= 30)
      .sort((a, b) => b.createdAt - a.createdAt);
  }, [state.expenses, driver.id]);

  const showToast = (msg, type = 'ok') => {
    setToast({ msg, type });
    setTimeout(() => setToast(null), 2800);
  };

  // Find incomplete trip for today or create new
  useEffect(() => {
    const open = myTrips.find(t => t.status === 'in_progress');
    if (open) setActiveTrip(open);
  }, [myTrips]);

  // Buses offered in the pre-trip selector: fleet list, always including the driver's own bus
  const fleetBuses = useMemo(() => {
    const list = [...((state && state.buses) || [])];
    if (driver.bus && !list.includes(driver.bus)) list.unshift(driver.bus);
    return list;
  }, [state.buses, driver.bus]);

  // Last ODO recorded for the selected bus — the pre-trip reading can never be lower
  const lastBusOdo = useMemo(
    () => lastOdometerForBus(state, setupBus),
    [state.trips, setupBus]
  );

  const openShiftSetup = () => {
    setSetupBus(driver.bus || fleetBuses[0] || '');
    setSetupBusManual(false);
    setSetupOdo('');
    setSetupMode(true);
  };

  const startNewShift = () => {
    const bus = String(setupBus || '').trim();
    const odo = Number(setupOdo);

    if (!bus) {
      showToast('Select or type a bus number', 'err');
      return;
    }
    // Start-trip ODO is OPTIONAL — only validate what was actually typed
    const hasStartOdo = setupOdo !== '' && !isNaN(odo);
    if (setupOdo !== '' && (isNaN(odo) || odo < 0)) {
      showToast('ODO must be a number (or leave it blank)', 'err');
      return;
    }
    // Sanity check runs only when a reading was entered
    if (hasStartOdo && lastBusOdo != null && odo < Number(lastBusOdo)) {
      showToast(`ODO cannot be below ${formatKm(lastBusOdo)} (last reading for ${bus})`, 'err');
      return;
    }

    const trip = {
      id: uid('TRIP'),
      driverId: driver.id,
      driverName: driver.name,
      bus,                                  // bus actually used for this shift
      busSource: setupBusManual ? 'manual' : 'auto',
      assignedBus: driver.bus || null,      // what the profile said, for auditing
      startOdometer: hasStartOdo ? odo : null,   // ODO meter before trip start (optional)
      status: 'in_progress',
      stages: {},
      createdAt: Date.now(),
      completedAt: null,
    };
    setState(s => {
      const next = { ...s, trips: [trip, ...s.trips] };
      saveState(next);
      return next;
    });
    setActiveTrip(trip);
    setSetupMode(false);
    setOdometerInput(hasStartOdo ? String(odo) : '');  // stage 1 prefilled when a reading exists
    setSetupOdo('');
    enqueue({ type: 'trip_start', data: trip });
    showToast(hasStartOdo ? `Shift started · ${bus} @ ${formatKm(odo)}` : `Shift started · ${bus} (no ODO)`);
  };

  // Highest reading already recorded inside this shift (start + every saved stage)
  const shiftFloor = useMemo(() => {
    if (!activeTrip) return null;
    const nums = [];
    if (activeTrip.startOdometer != null) nums.push(Number(activeTrip.startOdometer));
    Object.values(activeTrip.stages || {}).forEach(st => {
      if (st && st.odometer != null) nums.push(Number(st.odometer));
    });
    const clean = nums.filter(n => !isNaN(n));
    return clean.length ? Math.max(...clean) : null;
  }, [activeTrip]);

  const openFinish = () => {
    setFinishMode(true);
    setEndOdo('');
  };

  const endOdoBlank = endOdo === '';
  const endOdoNum = endOdoBlank ? null : Number(endOdo);
  const endOdoBelowFloor =
    endOdoNum != null && !isNaN(endOdoNum) && shiftFloor != null && endOdoNum < shiftFloor;
  // Blank is allowed; only a typed value below the floor blocks submission
  const endOdoValid = endOdoBlank || (endOdoNum != null && !isNaN(endOdoNum) && !endOdoBelowFloor);
  const previewDistance =
    endOdoValid && activeTrip && activeTrip.startOdometer != null
      ? endOdoNum - Number(activeTrip.startOdometer)
      : null;

  const finishShift = () => {
    if (!activeTrip) return;
    // End-trip ODO is OPTIONAL — a blank reading closes the shift with no distance
    const hasEndOdo = endOdo !== '' && endOdoNum != null && !isNaN(endOdoNum);
    if (endOdo !== '' && (endOdoNum == null || isNaN(endOdoNum))) {
      showToast('End ODO must be a number (or leave it blank)', 'err');
      return;
    }
    if (hasEndOdo && endOdoNum < 0) {
      showToast('ODO reading cannot be negative', 'err');
      return;
    }
    if (hasEndOdo && shiftFloor != null && endOdoNum < shiftFloor) {
      const startKm = activeTrip.startOdometer != null ? Number(activeTrip.startOdometer) : shiftFloor;
      showToast(
        endOdoNum < startKm
          ? `End ODO must be at least ${formatKm(startKm)} (shift start)`
          : `End ODO must be at least ${formatKm(shiftFloor)} (highest reading this shift)`,
        'err'
      );
      return;
    }

    const endedAt = Date.now();
    const recorded = Object.keys(activeTrip.stages || {}).length;
    const closedEarly = recorded < STAGES.length;

    setState(s => {
      const trips = s.trips.map(t => {
        if (t.id !== activeTrip.id) return t;
        return {
          ...t,
          endOdometer: hasEndOdo ? endOdoNum : null,   // ODO meter at end of trip (optional)
          endedAt,
          status: 'completed',
          completedAt: endedAt,
          closedBy: hasEndOdo ? 'end_odo' : 'no_odo',
          closedEarly,
        };
      });
      const next = { ...s, trips };
      saveState(next);
      return next;
    });

    setActiveTrip(prev => prev ? {
      ...prev,
      endOdometer: hasEndOdo ? endOdoNum : null,
      endedAt,
      status: 'completed',
      completedAt: endedAt,
      closedBy: hasEndOdo ? 'end_odo' : 'no_odo',
      closedEarly,
    } : prev);

    enqueue({
      type: 'trip_end',
      tripId: activeTrip.id,
      driverId: driver.id,
      data: { endOdometer: hasEndOdo ? endOdoNum : null, endedAt, bus: activeTrip.bus },
    });

    setFinishMode(false);
    setEndOdo('');
    setOdometerInput('');
    showToast(hasEndOdo ? `Shift closed · end ODO ${formatKm(endOdoNum)}` : 'Shift closed (no end ODO)');
  };

  const openCameraForStage = (stageKey) => {
    if (!odometerInput || isNaN(Number(odometerInput))) {
      showToast('Enter a valid odometer reading first', 'err');
      return;
    }
    // FIX: odometer can never go backwards across the 4 stages
    const idx = STAGES.findIndex(s => s.key === stageKey);
    const prevKey = idx > 0 ? STAGES[idx - 1].key : null;
    const prevKm = prevKey && activeTrip && activeTrip.stages[prevKey]
      ? activeTrip.stages[prevKey].odometer
      : null;
    if (prevKm != null && Number(odometerInput) < Number(prevKm)) {
      showToast(`Odometer must be at least ${prevKm} km (previous stage)`, 'err');
      return;
    }
    // Stage 1 can never be below the pre-trip ODO captured at shift start
    if (stageKey === 'start' && activeTrip && activeTrip.startOdometer != null &&
        Number(odometerInput) < Number(activeTrip.startOdometer)) {
      showToast(`ODO must be at least ${formatKm(activeTrip.startOdometer)} (pre-trip reading)`, 'err');
      return;
    }
    setCameraOpen(stageKey);
  };

  const handleCapture = (stageKey, photoData) => {
    const km = Number(odometerInput);
    const stageData = {
      odometer: km,
      photo: photoData.dataUrl,
      gps: photoData.gps,
      timestamp: photoData.timestamp,
    };

    setState(s => {
      const trips = s.trips.map(t => {
        if (t.id !== activeTrip.id) return t;
        const stages = { ...t.stages, [stageKey]: stageData };
        const done = STAGES.every(st => stages[st.key]);
        return {
          ...t,
          stages,
          status: done ? 'completed' : 'in_progress',
          completedAt: done ? Date.now() : null,
        };
      });
      const next = { ...s, trips };
      saveState(next);
      return next;
    });

    // Update local activeTrip
    setActiveTrip(prev => {
      if (!prev) return prev;
      const stages = { ...prev.stages, [stageKey]: stageData };
      const done = STAGES.every(st => stages[st.key]);
      return { ...prev, stages, status: done ? 'completed' : 'in_progress', completedAt: done ? Date.now() : null };
    });

    setCameraOpen(null);
    setOdometerInput('');
    showToast(`Stage "${STAGES.find(s => s.key === stageKey)?.title}" recorded`);

    // Enqueue for sync
    enqueue({ type: 'trip_stage', tripId: activeTrip.id, stageKey, data: stageData, driverId: driver.id });
  };

  const flushQueue = useCallback(async (items) => {
    // FIX: accept the freshly-built queue so a just-logged item is never dropped
    const batch = items || queue;
    if (!online || batch.length === 0) return;
    setSyncing(true);
    // Simulate network delay
    await new Promise(r => setTimeout(r, 900 + Math.random() * 600));
    console.log('[FleetShift] Syncing queue to cloud (simulated):', batch);
    const sent = new Set(batch.map(b => b.id));
    setQueue(q => {
      const rest = q.filter(x => !sent.has(x.id));
      saveQueue(rest);
      return rest;
    });
    setSyncing(false);
    showToast(`Synced ${batch.length} item(s)`);
  }, [online, queue]);

  const enqueue = (item) => {
    const entry = { ...item, id: uid('Q'), queuedAt: Date.now() };
    // Base on the persisted queue, not the render-time prop: two events fired in the
    // same render (e.g. trip_start then trip_end) would otherwise overwrite each other.
    const base = queue.length >= loadQueue().length ? queue : loadQueue();
    const next = [...base, entry];
    setQueue(next);
    saveQueue(next);
    if (online) flushQueue(next);
  };

  useEffect(() => {
    if (online && queue.length > 0) flushQueue();
  }, [online]);

  // Extra trip submit — start km and end km are both OPTIONAL
  const submitExtra = () => {
    const rawStart = String(extraForm.startKm ?? '').trim();
    const rawEnd = String(extraForm.endKm ?? '').trim();

    const hasStart = rawStart !== '' && !isNaN(Number(rawStart));
    const hasEnd = rawEnd !== '' && !isNaN(Number(rawEnd));
    const start = hasStart ? Number(rawStart) : null;
    const end = hasEnd ? Number(rawEnd) : null;

    // Only validate what was actually typed
    if (!hasStart && rawStart !== '') {
      showToast('Start km must be a number (or leave it blank)', 'err');
      return;
    }
    if (!hasEnd && rawEnd !== '') {
      showToast('End km must be a number (or leave it blank)', 'err');
      return;
    }
    if ((start != null && start < 0) || (end != null && end < 0)) {
      showToast('Odometer values cannot be negative', 'err');
      return;
    }
    // Sanity check only when both ends are known
    if (start != null && end != null && end < start) {
      showToast('End km cannot be lower than start km', 'err');
      return;
    }

    const distance = start != null && end != null ? end - start : null;

    const extra = {
      id: uid('EXT'),
      driverId: driver.id,
      driverName: driver.name,
      bus: driver.bus,
      startKm: start,          // null when left blank
      endKm: end,              // null when left blank
      distance,                // null unless both readings were entered
      note: extraForm.note || '',
      time: extraForm.time || new Date().toISOString().slice(0, 16),
      createdAt: Date.now(),
    };
    setState(s => {
      const next = { ...s, extras: [extra, ...s.extras] };
      saveState(next);
      return next;
    });
    enqueue({ type: 'extra', data: extra });
    setExtraForm({ startKm: '', endKm: '', note: '', time: '' });
    showToast(
      distance != null
        ? `Extra trip logged · ${distance} km`
        : 'Extra trip logged (no km readings)'
    );
  };

  // Write through localStorage so a full quota is reported instead of silently lost
  const persistState = (next) => {
    if (!saveState(next)) {
      showToast('Storage full — remove a receipt or attach a smaller photo', 'err');
      return false;
    }
    setState(next);
    return true;
  };

  const handleReceiptFile = async (file) => {
    if (!file) return;
    setReceiptBusy(true);
    try {
      const receipt = await fileToReceipt(file);
      const targetId = receiptTargetRef.current;
      if (targetId) {
        // Attaching / replacing the receipt on an already-saved expense
        const next = {
          ...state,
          expenses: state.expenses.map(x => x.id === targetId ? { ...x, receipt } : x),
        };
        if (persistState(next)) showToast('Receipt updated');
        receiptTargetRef.current = null;
      } else {
        setReceiptDraft(receipt);
        showToast('Receipt attached');
      }
    } catch (e) {
      showToast(e.message || 'Could not attach that file', 'err');
      receiptTargetRef.current = null;
    } finally {
      setReceiptBusy(false);
      if (receiptCamRef.current) receiptCamRef.current.value = '';
      if (receiptFileRef.current) receiptFileRef.current.value = '';
    }
  };

  const pickReceipt = (expenseId = null, useCamera = false) => {
    receiptTargetRef.current = expenseId;
    const el = useCamera ? receiptCamRef.current : receiptFileRef.current;
    if (el) el.click();
  };

  const removeReceipt = (expenseId = null) => {
    if (!expenseId) {
      setReceiptDraft(null);
      showToast('Receipt removed');
      return;
    }
    const next = {
      ...state,
      expenses: state.expenses.map(x => x.id === expenseId ? { ...x, receipt: null } : x),
    };
    if (persistState(next)) showToast('Receipt removed');
    if (viewReceipt && viewReceipt.id === expenseId) setViewReceipt(null);
  };

  // Expense submit
  const submitExpense = () => {
    let amount = 0;
    if (expMode === 'calc') {
      const liters = Number(expForm.liters);
      const price = Number(expForm.price);
      if (!liters || !price) {
        showToast('Enter liters and price', 'err');
        return;
      }
      amount = +(liters * price).toFixed(2);
    } else {
      amount = Number(expForm.total);
      if (!amount) {
        showToast('Enter total amount', 'err');
        return;
      }
    }
    const exp = {
      id: uid('EXP'),
      driverId: driver.id,
      driverName: driver.name,
      bus: driver.bus,
      type: expForm.type,
      mode: expMode,
      liters: expMode === 'calc' ? Number(expForm.liters) : null,
      unitPrice: expMode === 'calc' ? Number(expForm.price) : null,
      amount,
      note: expForm.note || '',
      receipt: receiptDraft || null,   // optional photo / PDF of the receipt
      createdAt: Date.now(),
    };
    // Never ship the base64 blob into the offline queue — only its metadata
    const { receipt, ...queuePayload } = exp;
    if (!persistState({ ...state, expenses: [exp, ...state.expenses] })) return;
    enqueue({
      type: 'expense',
      data: {
        ...queuePayload,
        receiptMeta: receipt ? { name: receipt.name, type: receipt.type, size: receipt.size } : null,
      },
    });
    setExpForm({ liters: '', price: '2.85', total: '', note: '', type: 'fuel' });
    setReceiptDraft(null);
    showToast(receipt ? 'Expense recorded with receipt' : 'Expense recorded');
  };

  const currentStageIndex = activeTrip
    ? STAGES.findIndex(s => !activeTrip.stages[s.key])
    : -1;

  const activeBus = (activeTrip && activeTrip.bus) || driver.bus;

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-slate-900/95 border-b border-slate-800 backdrop-blur px-4 py-3">
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-xs text-slate-400">Driver Portal</div>
            <div className="font-semibold text-sm truncate">{driver.name}</div>
            <div className="text-[11px] text-sky-400 font-mono">
              {activeBus} · {driver.id}
              {activeTrip && activeTrip.busSource === 'manual' && (
                <span className="ml-1 text-amber-400">(manual)</span>
              )}
            </div>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            <NetworkBadge
              online={online}
              syncing={syncing}
              queueLen={queue.length}
              onToggle={() => setOnline(o => !o)}
            />
            <button onClick={onLogout} className="p-2 rounded-lg bg-slate-800 text-slate-300">
              <Icon name="LogOut" size={16} />
            </button>
          </div>
        </div>
      </header>

      {/* Toast */}
      {toast && (
        <div className={`fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-sm font-medium shadow-lg fade-in ${
          toast.type === 'err' ? 'bg-red-600 text-white' : 'bg-emerald-600 text-white'
        }`}>
          {toast.msg}
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 overflow-y-auto pb-24 px-4 pt-4">
        {tab === 'shift' && (
          <div className="space-y-4 fade-in">
            {!activeTrip || setupMode ? (
              <div className="card p-5">
                <div className="flex items-center gap-2 font-semibold mb-1">
                  <Icon name="ClipboardCheck" size={18} className="text-sky-400" />
                  Pre-Trip Check
                </div>
                <p className="text-xs text-slate-400 mb-4">
                  Confirm the bus and record the ODO meter before the trip starts.
                </p>

                {/* Bus number — auto-selected from the driver profile, manual override available */}
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs text-slate-400">Bus number</label>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    setupBusManual
                      ? 'bg-amber-500/15 text-amber-400'
                      : 'bg-emerald-500/15 text-emerald-400'
                  }`}>
                    {setupBusManual ? 'MANUAL' : 'AUTO-SELECTED'}
                  </span>
                </div>
                <select
                  value={setupBusManual ? '__manual__' : setupBus}
                  onChange={e => {
                    const v = e.target.value;
                    if (v === '__manual__') { setSetupBusManual(true); }
                    else { setSetupBusManual(false); setSetupBus(v); }
                  }}
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 font-mono mb-2"
                >
                  {fleetBuses.map(b => (
                    <option key={b} value={b}>
                      {b}{b === driver.bus ? ' · assigned to you' : ''}
                    </option>
                  ))}
                  <option value="__manual__">Manual entry…</option>
                </select>
                {setupBusManual && (
                  <input
                    value={setupBus}
                    onChange={e => setSetupBus(e.target.value.toUpperCase())}
                    placeholder="e.g. DXB-6600"
                    className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 font-mono mb-1"
                  />
                )}
                <div className="text-[11px] text-slate-500 mb-4">
                  {setupBusManual
                    ? 'Type the bus number if it is not in the fleet list — flagged as manual for the admin.'
                    : (driver.bus
                        ? `Auto-selected from your profile (${driver.bus}).`
                        : 'No bus assigned to your profile — pick one above or enter it manually.')}
                </div>

                {/* ODO meter before trip start */}
                <label className="text-xs text-slate-400 block mb-1">
                  ODO meter before trip start (km) <span className="text-slate-500">· optional</span>
                </label>
                <input
                  type="number"
                  inputMode="numeric"
                  value={setupOdo}
                  onChange={e => setSetupOdo(e.target.value)}
                  placeholder="e.g. 124580"
                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-base font-mono"
                />
                <div className="text-[11px] text-slate-500 mt-1 mb-4">
                  {lastBusOdo != null
                    ? `Last recorded for ${setupBus || 'this bus'}: ${formatKm(lastBusOdo)}`
                    : `No previous reading recorded for ${setupBus || 'this bus'}`}
                  <span className="block text-slate-600 mt-0.5">
                    Leave blank if the meter cannot be read — the shift still starts.
                  </span>
                  {setupOdo !== '' && lastBusOdo != null && Number(setupOdo) < Number(lastBusOdo) && (
                    <span className="block text-red-400 mt-1">
                      Cannot be below the last recorded reading.
                    </span>
                  )}
                </div>

                <button
                  onClick={startNewShift}
                  disabled={!setupBus}
                  className="w-full py-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold"
                >
                  Start Shift · {setupBus || 'no bus selected'}
                </button>
                {setupMode && activeTrip && (
                  <button
                    onClick={() => setSetupMode(false)}
                    className="w-full mt-2 text-xs text-slate-400 hover:text-sky-400 py-1"
                  >
                    Cancel · back to shift summary
                  </button>
                )}
              </div>
            ) : activeTrip.status === 'completed' ? (
              <div className="space-y-4">
                <div className="card p-5 border-emerald-500/40 bg-emerald-500/5">
                  <div className="flex items-center gap-2 font-semibold text-emerald-300 mb-1">
                    <Icon name="CheckCircle" size={20} /> Shift Complete
                  </div>
                  <div className="text-xs text-slate-400 font-mono">
                    {activeTrip.bus}
                    {activeTrip.busSource === 'manual' && <span className="text-amber-400"> (manual)</span>}
                    {' '}· {formatDate(activeTrip.completedAt)}
                  </div>
                  <div className="mt-3 grid grid-cols-3 gap-2 text-center">
                    <div className="bg-slate-800/60 rounded-lg p-2">
                      <div className="text-[10px] text-slate-500 uppercase tracking-wide">ODO start</div>
                      <div className="font-mono text-xs text-slate-200 mt-0.5">
                        {activeTrip.startOdometer != null ? formatKm(activeTrip.startOdometer) : '—'}
                      </div>
                    </div>
                    <div className="bg-slate-800/60 rounded-lg p-2">
                      <div className="text-[10px] text-slate-500 uppercase tracking-wide">ODO end</div>
                      <div className="font-mono text-xs text-slate-200 mt-0.5">
                        {activeTrip.endOdometer != null
                          ? formatKm(activeTrip.endOdometer)
                          : (activeTrip.stages.final ? formatKm(activeTrip.stages.final.odometer) : '—')}
                      </div>
                    </div>
                    <div className="bg-slate-800/60 rounded-lg p-2">
                      <div className="text-[10px] text-slate-500 uppercase tracking-wide">Distance</div>
                      <div className="font-mono text-xs text-sky-300 mt-0.5">
                        {formatKm(shiftDistance(activeTrip))}
                      </div>
                    </div>
                  </div>
                  {activeTrip.closedEarly && (
                    <div className="mt-2 text-[11px] text-amber-400">
                      Closed with {Object.keys(activeTrip.stages).length} of {STAGES.length} stages recorded.
                    </div>
                  )}
                  <div className="mt-3 space-y-1.5">
                    {STAGES.map(st => {
                      const d = activeTrip.stages[st.key];
                      return (
                        <div key={st.key} className="flex items-center justify-between gap-2 text-xs">
                          <span className="text-slate-400 truncate">{st.title}</span>
                          <span className="font-mono text-emerald-300 shrink-0">
                            {d ? formatKm(d.odometer) : '—'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                  <div className="mt-3 pt-3 border-t border-slate-800 flex items-center justify-between text-sm">
                    <span className="text-slate-400">Shift distance</span>
                    <span className="font-mono font-semibold text-sky-300">
                      {formatKm(shiftDistance(activeTrip))}
                    </span>
                  </div>
                </div>
                <button
                  onClick={openShiftSetup}
                  className="w-full py-3.5 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
                >
                  Start New Shift
                </button>
              </div>
            ) : (
              <>
                {/* Pre-trip record */}
                <div className="card p-3 flex items-center justify-between gap-2 text-xs">
                  <div className="flex items-center gap-2 min-w-0">
                    <Icon name="Bus" size={14} className="text-sky-400 shrink-0" />
                    <span className="font-mono font-semibold truncate">{activeTrip.bus}</span>
                    <span className={`text-[9px] font-semibold px-1.5 py-0.5 rounded shrink-0 ${
                      activeTrip.busSource === 'manual'
                        ? 'bg-amber-500/15 text-amber-400'
                        : 'bg-emerald-500/15 text-emerald-400'
                    }`}>
                      {activeTrip.busSource === 'manual' ? 'MANUAL' : 'AUTO'}
                    </span>
                  </div>
                  <div className="text-slate-400 shrink-0">
                    ODO start{' '}
                    <span className="font-mono text-slate-200">{formatKm(activeTrip.startOdometer)}</span>
                  </div>
                </div>

                {/* Progress */}
                <div className="card p-4">
                  <div className="flex justify-between text-xs text-slate-400 mb-2">
                    <span>Shift Progress</span>
                    <span>{Object.keys(activeTrip.stages).length} / 4</span>
                  </div>
                  <div className="stage-bar">
                    <div
                      className="stage-bar-fill"
                      style={{ width: `${(Object.keys(activeTrip.stages).length / 4) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Finish shift by end-trip ODO */}
                {!finishMode ? (
                  <button
                    onClick={openFinish}
                    className="w-full card card-hover p-4 flex items-center justify-between text-left"
                  >
                    <span className="flex items-center gap-2 text-sm font-medium text-emerald-300">
                      <Icon name="Flag" size={16} /> Finish Shift
                    </span>
                    <span className="text-[11px] text-slate-500">enter end-trip ODO</span>
                  </button>
                ) : (
                  <div className="card p-4 border-emerald-500/40 fade-in">
                    <div className="flex items-center gap-2 font-semibold mb-1 text-emerald-300">
                      <Icon name="Flag" size={16} /> End of Trip
                    </div>
                    <p className="text-xs text-slate-400 mb-3">
                      Enter the ODO meter reading now to close this shift.
                    </p>
                    <label className="text-xs text-slate-400 block mb-1">
                      ODO meter at end of trip (km) <span className="text-slate-500">· optional</span>
                    </label>
                    <input
                      type="number"
                      inputMode="numeric"
                      value={endOdo}
                      onChange={e => setEndOdo(e.target.value)}
                      onKeyDown={e => e.key === 'Enter' && finishShift()}
                      placeholder={shiftFloor != null ? String(shiftFloor) : 'e.g. 124712'}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-base font-mono"
                      autoFocus
                    />
                    <div className="text-[11px] text-slate-500 mt-1 space-y-0.5">
                      <div>Started at {formatKm(activeTrip.startOdometer)}</div>
                      <div>Highest reading so far {formatKm(shiftFloor)}</div>
                      <div className="text-slate-600">
                        Leave blank to close without an end reading.
                      </div>
                      {endOdo !== '' && endOdoValid && (
                        <div className="text-emerald-400">
                          Distance for this shift: {formatKm(previewDistance)}
                        </div>
                      )}
                      {endOdo !== '' && !endOdoValid && (
                        <div className="text-red-400">
                          End ODO cannot be below {formatKm(shiftFloor)}.
                        </div>
                      )}
                      {Object.keys(activeTrip.stages).length < STAGES.length && (
                        <div className="text-amber-400">
                          {STAGES.length - Object.keys(activeTrip.stages).length} stage(s) not recorded —
                          the shift will close as partially logged.
                        </div>
                      )}
                    </div>
                    <button
                      onClick={finishShift}
                      disabled={!endOdoValid}
                      className="w-full mt-3 py-3 rounded-xl bg-emerald-500 hover:bg-emerald-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold"
                    >
                      Confirm End & Close Shift
                    </button>
                    <button
                      onClick={() => { setFinishMode(false); setEndOdo(''); }}
                      className="w-full mt-2 text-xs text-slate-400 hover:text-sky-400 py-1"
                    >
                      Cancel
                    </button>
                  </div>
                )}

                {/* Stages */}
                {STAGES.map((stage, idx) => {
                  const done = !!activeTrip.stages[stage.key];
                  const isCurrent = idx === currentStageIndex;
                  const locked = idx > currentStageIndex;
                  const data = activeTrip.stages[stage.key];

                  return (
                    <div
                      key={stage.key}
                      className={`card p-4 transition-all ${
                        done ? 'stage-done' : isCurrent ? 'stage-active' : 'stage-locked'
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                          done ? 'bg-emerald-500/20 text-emerald-400' :
                          isCurrent ? 'bg-sky-500/20 text-sky-400' : 'bg-slate-800 text-slate-500'
                        }`}>
                          <Icon name={done ? 'Check' : stage.icon} size={20} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="font-semibold text-sm">{stage.title}</div>
                          <div className="text-xs text-slate-400 mb-2">{stage.subtitle}</div>

                          {done && data && (
                            <div className="mt-2 space-y-2">
                              <div className="text-xs font-mono text-emerald-300">
                                {formatKm(data.odometer)} · {formatDate(data.timestamp)}
                              </div>
                              {data.photo && (
                                <img
                                  src={data.photo}
                                  alt="proof"
                                  className="rounded-lg max-h-32 object-cover border border-slate-700"
                                />
                              )}
                            </div>
                          )}

                          {isCurrent && (
                            <div className="mt-3 space-y-3">
                              <div>
                                <label className="text-xs text-slate-400 block mb-1">Odometer (km)</label>
                                <input
                                  type="number"
                                  inputMode="decimal"
                                  value={odometerInput}
                                  onChange={e => setOdometerInput(e.target.value)}
                                  placeholder="e.g. 124580"
                                  className="w-full bg-slate-800 border border-slate-700 rounded-xl px-4 py-3 text-base"
                                />
                                {stage.key === 'start' && activeTrip.startOdometer != null && (
                                  <div className="text-[11px] text-slate-500 mt-1">
                                    Pre-trip ODO: {formatKm(activeTrip.startOdometer)}
                                  </div>
                                )}
                              </div>
                              <button
                                onClick={() => openCameraForStage(stage.key)}
                                className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold flex items-center justify-center gap-2"
                              >
                                <Icon name="Camera" size={18} />
                                Capture Photo & Save Stage
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}

              </>
            )}
          </div>
        )}

        {tab === 'extras' && (
          <div className="space-y-4 fade-in">
            <div className="card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Icon name="Route" size={18} className="text-sky-400" /> Extra / Inter-City Trip
              </h3>
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div>
                  <label className="text-xs text-slate-400">Start km (optional)</label>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={extraForm.startKm}
                    onChange={e => setExtraForm(f => ({ ...f, startKm: e.target.value }))}
                    placeholder="—"
                    className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 font-mono"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400">End km (optional)</label>
                  <input
                    type="number"
                    inputMode="numeric"
                    value={extraForm.endKm}
                    onChange={e => setExtraForm(f => ({ ...f, endKm: e.target.value }))}
                    placeholder="—"
                    className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 font-mono"
                  />
                </div>
              </div>
              <div className="text-[11px] text-slate-500 -mt-2 mb-3">
                {extraForm.startKm !== '' && extraForm.endKm !== '' &&
                 !isNaN(Number(extraForm.startKm)) && !isNaN(Number(extraForm.endKm)) &&
                 Number(extraForm.endKm) >= Number(extraForm.startKm)
                  ? `Distance ${Number(extraForm.endKm) - Number(extraForm.startKm)} km`
                  : 'Both km readings are optional — enter both to record a distance.'}
              </div>
              <div className="mb-3">
                <label className="text-xs text-slate-400">Departure time</label>
                <input
                  type="datetime-local"
                  value={extraForm.time}
                  onChange={e => setExtraForm(f => ({ ...f, time: e.target.value }))}
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                />
              </div>
              <div className="mb-4">
                <label className="text-xs text-slate-400">Note (optional)</label>
                <input
                  type="text"
                  value={extraForm.note}
                  onChange={e => setExtraForm(f => ({ ...f, note: e.target.value }))}
                  placeholder="e.g. Airport shuttle"
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                />
              </div>
              <button
                onClick={submitExtra}
                className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
              >
                Log Extra Trip
              </button>
            </div>

            {myExtras.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs text-slate-500 uppercase tracking-wide">Recent (30 days)</div>
                {myExtras.map(ex => (
                  <div key={ex.id} className="card p-3 text-sm">
                    <div className="flex justify-between gap-2">
                      <span className="font-medium font-mono text-xs text-slate-300">
                        {ex.startKm != null && ex.startKm !== '' ? formatKm(ex.startKm) : '—'}
                        {' → '}
                        {ex.endKm != null && ex.endKm !== '' ? formatKm(ex.endKm) : '—'}
                      </span>
                      {ex.distance != null ? (
                        <span className="text-sky-400 font-mono text-xs shrink-0">{ex.distance} km</span>
                      ) : (
                        <span className="text-slate-500 text-xs shrink-0">no km reading</span>
                      )}
                    </div>
                    {ex.note && <div className="text-slate-400 text-xs mt-1">{ex.note}</div>}
                    <div className="text-[11px] text-slate-500 mt-1">{formatDate(ex.createdAt)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'expenses' && (
          <div className="space-y-4 fade-in">
            <div className="card p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Icon name="Fuel" size={18} className="text-amber-400" /> Fuel & Expenses
              </h3>

              <div className="flex gap-2 mb-4">
                <button
                  onClick={() => setExpMode('calc')}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium ${
                    expMode === 'calc' ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Calculation
                </button>
                <button
                  onClick={() => setExpMode('direct')}
                  className={`flex-1 py-2 rounded-lg text-sm font-medium ${
                    expMode === 'direct' ? 'bg-sky-500 text-white' : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  Direct Entry
                </button>
              </div>

              <div className="mb-3">
                <label className="text-xs text-slate-400">Type</label>
                <select
                  value={expForm.type}
                  onChange={e => setExpForm(f => ({ ...f, type: e.target.value }))}
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                >
                  <option value="fuel">Fuel</option>
                  <option value="wash">Vehicle Wash</option>
                  <option value="parking">Parking</option>
                  <option value="maintenance">Minor Maintenance</option>
                  <option value="other">Other</option>
                </select>
              </div>

              {expMode === 'calc' ? (
                <div className="grid grid-cols-2 gap-3 mb-3">
                  <div>
                    <label className="text-xs text-slate-400">Liters</label>
                    <input
                      type="number"
                      step="0.01"
                      value={expForm.liters}
                      onChange={e => setExpForm(f => ({ ...f, liters: e.target.value }))}
                      className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                  </div>
                  <div>
                    <label className="text-xs text-slate-400">Price / L (AED)</label>
                    <input
                      type="number"
                      step="0.01"
                      value={expForm.price}
                      onChange={e => setExpForm(f => ({ ...f, price: e.target.value }))}
                      className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                  </div>
                  {expForm.liters && expForm.price && (
                    <div className="col-span-2 text-center text-sm text-emerald-400 font-mono">
                      = {(Number(expForm.liters) * Number(expForm.price)).toFixed(2)} AED
                    </div>
                  )}
                </div>
              ) : (
                <div className="mb-3">
                  <label className="text-xs text-slate-400">Total Amount (AED)</label>
                  <input
                    type="number"
                    step="0.01"
                    value={expForm.total}
                    onChange={e => setExpForm(f => ({ ...f, total: e.target.value }))}
                    className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                  />
                </div>
              )}

              <div className="mb-3">
                <label className="text-xs text-slate-400">Note</label>
                <input
                  type="text"
                  value={expForm.note}
                  onChange={e => setExpForm(f => ({ ...f, note: e.target.value }))}
                  placeholder="Station / description"
                  className="w-full mt-1 bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                />
              </div>

              {/* Receipt upload — optional */}
              <div className="mb-4">
                <label className="text-xs text-slate-400 block mb-1">
                  Receipt <span className="text-slate-600">· optional</span>
                </label>
                {receiptBusy ? (
                  <div className="flex items-center gap-2 text-xs text-slate-400 py-2">
                    <Icon name="Loader" size={14} className="animate-spin" /> Preparing receipt…
                  </div>
                ) : receiptDraft ? (
                  <div className="flex items-center gap-2 bg-slate-800/60 border border-slate-700 rounded-xl p-2">
                    {receiptDraft.type && receiptDraft.type.startsWith('image/') ? (
                      <img
                        src={receiptDraft.dataUrl}
                        alt="receipt preview"
                        className="w-12 h-12 object-cover rounded-lg border border-slate-700 shrink-0"
                      />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-slate-700 flex items-center justify-center shrink-0">
                        <Icon name="FileText" size={18} className="text-slate-300" />
                      </div>
                    )}
                    <div className="min-w-0 flex-1">
                      <div className="text-xs truncate">{receiptDraft.name}</div>
                      <div className="text-[10px] text-slate-500">
                        {receiptDraft.type === 'application/pdf' ? 'PDF' : 'Photo'} · {formatBytes(receiptDraft.size)}
                      </div>
                    </div>
                    <button
                      onClick={() => removeReceipt(null)}
                      className="p-1.5 rounded-lg bg-slate-700 text-slate-300 shrink-0"
                    >
                      <Icon name="X" size={14} />
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => pickReceipt(null, true)}
                      className="py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 text-sm font-medium flex items-center justify-center gap-1.5"
                    >
                      <Icon name="Camera" size={15} /> Take photo
                    </button>
                    <button
                      onClick={() => pickReceipt(null, false)}
                      className="py-2.5 rounded-xl bg-slate-800 border border-slate-700 text-slate-200 text-sm font-medium flex items-center justify-center gap-1.5"
                    >
                      <Icon name="Upload" size={15} /> Upload file
                    </button>
                  </div>
                )}
                <div className="text-[10px] text-slate-600 mt-1">
                  Photo or PDF up to {formatBytes(RECEIPT_MAX_BYTES)}. Photos are compressed to fit.
                </div>
              </div>

              <button
                onClick={submitExpense}
                className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-900 font-semibold"
              >
                {receiptDraft ? 'Save Expense + Receipt' : 'Save Expense'}
              </button>
            </div>

            {myExpenses.length > 0 && (
              <div className="space-y-2">
                <div className="text-xs text-slate-500 uppercase tracking-wide">Recent (30 days)</div>
                {myExpenses.map(ex => (
                  <div key={ex.id} className="card p-3 text-sm">
                    <div className="flex justify-between items-center">
                      <span className="capitalize font-medium">{ex.type}</span>
                      <span className="text-amber-400 font-mono font-semibold">{Number(ex.amount || 0).toFixed(2)} AED</span>
                    </div>
                    {ex.liters && (
                      <div className="text-xs text-slate-400 mt-0.5">{ex.liters} L × {ex.unitPrice} AED</div>
                    )}
                    {ex.note && <div className="text-slate-400 text-xs mt-1">{ex.note}</div>}

                    {/* Receipt — also offered for older expenses saved before receipts existed */}
                    {ex.receipt && ex.receipt.dataUrl ? (
                      <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-800">
                        {ex.receipt.type && ex.receipt.type.startsWith('image/') ? (
                          <img
                            src={ex.receipt.dataUrl}
                            alt="receipt"
                            onClick={() => setViewReceipt(ex)}
                            className="w-11 h-11 object-cover rounded-lg border border-slate-700 cursor-pointer shrink-0"
                          />
                        ) : (
                          <div
                            onClick={() => setViewReceipt(ex)}
                            className="w-11 h-11 rounded-lg bg-slate-700 flex items-center justify-center cursor-pointer shrink-0"
                          >
                            <Icon name="FileText" size={16} className="text-slate-300" />
                          </div>
                        )}
                        <button
                          onClick={() => setViewReceipt(ex)}
                          className="flex-1 text-left text-xs text-sky-400 font-medium min-w-0"
                        >
                          View receipt
                          <span className="block text-[10px] text-slate-500 font-normal truncate">
                            {ex.receipt.name || 'receipt'} · {formatBytes(ex.receipt.size)}
                          </span>
                        </button>
                        <button
                          onClick={() => pickReceipt(ex.id, false)}
                          title="Replace receipt"
                          className="p-1.5 rounded-lg bg-slate-800 text-slate-400 shrink-0"
                        >
                          <Icon name="RefreshCw" size={13} />
                        </button>
                        <button
                          onClick={() => removeReceipt(ex.id)}
                          title="Remove receipt"
                          className="p-1.5 rounded-lg bg-slate-800 text-slate-400 shrink-0"
                        >
                          <Icon name="Trash2" size={13} />
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between gap-2 mt-2 pt-2 border-t border-slate-800">
                        <span className="text-[11px] text-slate-600">No receipt attached</span>
                        <button
                          onClick={() => pickReceipt(ex.id, false)}
                          className="text-[11px] text-amber-400 font-medium flex items-center gap-1 shrink-0"
                        >
                          <Icon name="Paperclip" size={12} /> Attach
                        </button>
                      </div>
                    )}

                    <div className="text-[11px] text-slate-500 mt-1">{formatDate(ex.createdAt)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {tab === 'history' && (
          <div className="space-y-3 fade-in">
            <div className="text-xs text-slate-500 uppercase tracking-wide">Your logs (last 30 days)</div>
            {myTrips.length === 0 && (
              <div className="card p-6 text-center text-slate-500 text-sm">No trips yet</div>
            )}
            {myTrips.map(t => (
              <div key={t.id} className="card p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <div className="font-medium text-sm">{formatDate(t.createdAt)}</div>
                    <div className="text-xs text-slate-400 font-mono">{t.bus}</div>
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    t.status === 'completed' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-amber-500/20 text-amber-400'
                  }`}>
                    {t.status === 'completed' ? 'Completed' : 'In Progress'}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {STAGES.map(s => {
                    const d = t.stages[s.key];
                    return (
                      <div key={s.key} className="bg-slate-800/60 rounded-lg p-2">
                        <div className="text-slate-500 truncate">{s.title}</div>
                        <div className="font-mono text-sky-300">{d ? formatKm(d.odometer) : '—'}</div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Bottom nav */}
      <nav className="fixed bottom-0 inset-x-0 bg-slate-900/95 border-t border-slate-800 backdrop-blur safe-bottom z-30">
        <div className="flex justify-around py-2">
          {[
            { id: 'shift', icon: 'ClipboardList', label: 'Shift' },
            { id: 'extras', icon: 'Route', label: 'Extras' },
            { id: 'expenses', icon: 'Wallet', label: 'Expenses' },
            { id: 'history', icon: 'History', label: 'History' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg text-[10px] font-medium ${
                tab === item.id ? 'text-sky-400' : 'text-slate-500'
              }`}
            >
              <Icon name={item.icon} size={20} />
              {item.label}
            </button>
          ))}
        </div>
      </nav>

      {/* Shared hidden pickers: camera capture and file browse (attach / replace on saved expenses) */}
      <input
        ref={receiptCamRef}
        type="file"
        accept={RECEIPT_ACCEPT}
        capture="environment"
        className="hidden"
        onChange={e => handleReceiptFile(e.target.files && e.target.files[0])}
      />
      <input
        ref={receiptFileRef}
        type="file"
        accept={RECEIPT_ACCEPT}
        className="hidden"
        onChange={e => handleReceiptFile(e.target.files && e.target.files[0])}
      />

      {/* Receipt viewer */}
      {viewReceipt && viewReceipt.receipt && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center modal-backdrop p-4"
          onClick={() => setViewReceipt(null)}
        >
          <div
            className="card w-full max-w-md max-h-[85vh] overflow-hidden flex flex-col fade-in"
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between gap-2 px-4 py-3 border-b border-slate-800">
              <div className="min-w-0">
                <div className="text-sm font-semibold truncate">
                  {viewReceipt.receipt.name || 'Receipt'}
                </div>
                <div className="text-[11px] text-slate-500">
                  {viewReceipt.type} · {Number(viewReceipt.amount || 0).toFixed(2)} AED ·{' '}
                  {formatBytes(viewReceipt.receipt.size)}
                </div>
              </div>
              <button
                onClick={() => setViewReceipt(null)}
                className="p-2 rounded-lg bg-slate-800 text-slate-300 shrink-0"
              >
                <Icon name="X" size={16} />
              </button>
            </div>
            <div className="flex-1 overflow-auto p-3 bg-slate-950">
              {viewReceipt.receipt.type && viewReceipt.receipt.type.startsWith('image/') ? (
                <img src={viewReceipt.receipt.dataUrl} alt="receipt" className="w-full rounded-lg" />
              ) : (
                <div className="text-center py-10 text-slate-400 text-sm">
                  <Icon name="FileText" size={32} className="mx-auto mb-3 text-slate-500" />
                  PDF receipt — open it in a new tab to read.
                  <a
                    href={viewReceipt.receipt.dataUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="block mt-3 text-sky-400 font-medium"
                  >
                    Open PDF
                  </a>
                </div>
              )}
            </div>
            <div className="px-4 py-3 border-t border-slate-800 flex gap-2">
              <button
                onClick={() => { pickReceipt(viewReceipt.id, false); setViewReceipt(null); }}
                className="flex-1 py-2 rounded-lg bg-slate-800 text-slate-200 text-xs font-medium flex items-center justify-center gap-1"
              >
                <Icon name="RefreshCw" size={13} /> Replace
              </button>
              <button
                onClick={() => removeReceipt(viewReceipt.id)}
                className="flex-1 py-2 rounded-lg bg-red-500/15 text-red-400 text-xs font-medium border border-red-500/30 flex items-center justify-center gap-1"
              >
                <Icon name="Trash2" size={13} /> Remove
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Camera modal */}
      {cameraOpen && (
        <WatermarkCamera
          driver={driver}
          bus={driver.bus}
          onCapture={(data) => handleCapture(cameraOpen, data)}
          onCancel={() => setCameraOpen(null)}
        />
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Admin Portal
// ─────────────────────────────────────────────
function AdminPortal({ state, setState, online, setOnline, queue, setQueue, onLogout }) {
  const [tab, setTab] = useState('overview'); // overview | drivers | audit | buses
  const [showAddDriver, setShowAddDriver] = useState(false);
  const [newDriver, setNewDriver] = useState({ name: '', id: '', bus: '', phone: '', pin: '' });
  const [toast, setToast] = useState(null);
  const [pinResetNotice, setPinResetNotice] = useState(null); // { driverId, pin }

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  };

  const stats = useMemo(() => {
    const trips = state.trips || [];
    const expenses = state.expenses || [];
    const extras = state.extras || [];
    const completed = trips.filter(t => t.status === 'completed').length;
    const inProg = trips.filter(t => t.status === 'in_progress').length;
    const totalExp = expenses.reduce((s, e) => s + (e.amount || 0), 0);
    const activeDrivers = (state.drivers || []).filter(d => d.status === 'active').length;
    return { completed, inProg, totalExp, activeDrivers, extras: extras.length, trips: trips.length };
  }, [state]);

  const allSubmissions = useMemo(() => {
    const items = [];
    (state.trips || []).forEach(t => {
      items.push({
        id: t.id,
        type: 'trip',
        driverName: t.driverName,
        bus: t.bus,
        status: t.status,
        createdAt: t.createdAt,
        detail: `${Object.keys(t.stages || {}).length}/4 stages`
          + (t.startOdometer != null ? ` · ODO start ${Number(t.startOdometer).toLocaleString('en')} km` : '')
          + (t.endOdometer != null ? ` → end ${Number(t.endOdometer).toLocaleString('en')} km` : '')
          + (shiftDistance(t) != null && t.endOdometer != null
              ? ` · ${Number(shiftDistance(t)).toLocaleString('en')} km`
              : '')
          + (t.closedEarly ? ' · partial log' : '')
          + (t.busSource === 'manual' ? ' · manual bus' : ''),
      });
    });
    (state.extras || []).forEach(e => {
      items.push({
        id: e.id,
        type: 'extra',
        driverName: e.driverName,
        bus: e.bus,
        status: 'logged',
        createdAt: e.createdAt,
        detail: e.distance != null ? `${e.distance} km` : 'no km reading',
      });
    });
    (state.expenses || []).forEach(e => {
      items.push({
        id: e.id,
        type: 'expense',
        driverName: e.driverName,
        bus: e.bus,
        status: e.type,
        createdAt: e.createdAt,
        hasReceipt: !!(e.receipt && e.receipt.dataUrl),
        detail: `${Number(e.amount || 0).toFixed(2)} AED${e.receipt && e.receipt.dataUrl ? ' · receipt' : ''}`,
      });
    });
    return items.sort((a, b) => b.createdAt - a.createdAt);
  }, [state]);

  const toggleDriver = (id) => {
    setState(s => {
      const drivers = s.drivers.map(d =>
        d.id === id ? { ...d, status: d.status === 'active' ? 'locked' : 'active' } : d
      );
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    showToast('Driver status updated');
  };

  const reassignBus = (driverId, bus) => {
    setState(s => {
      const drivers = s.drivers.map(d => d.id === driverId ? { ...d, bus } : d);
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    showToast('Bus reassigned');
  };

  const addDriver = () => {
    if (!newDriver.name || !newDriver.id || !newDriver.bus) {
      showToast('Name, ID and Bus are required');
      return;
    }
    if (state.drivers.some(d => d.id === newDriver.id)) {
      showToast('Driver ID already exists');
      return;
    }
    const pin = (newDriver.pin || '').trim() || newDriver.id.replace(/\D/g, '').slice(-4) || '0000';
    if (pin.length < 4) {
      showToast('PIN must be at least 4 digits');
      return;
    }
    const d = {
      id: newDriver.id,
      name: newDriver.name,
      bus: newDriver.bus,
      phone: newDriver.phone || '',
      pin,
      status: 'active',
    };
    setState(s => {
      const buses = s.buses.includes(d.bus) ? s.buses : [...s.buses, d.bus];
      const next = { ...s, drivers: [...s.drivers, d], buses };
      saveState(next);
      return next;
    });
    setNewDriver({ name: '', id: '', bus: '', phone: '', pin: '' });
    setShowAddDriver(false);
    showToast('Driver added');
  };

  const updateDriverPin = (driverId, pin) => {
    const cleaned = String(pin || '').replace(/\D/g, '').slice(0, 6);
    if (cleaned.length < 4) {
      showToast('PIN must be at least 4 digits');
      return;
    }
    setState(s => {
      const drivers = s.drivers.map(d => d.id === driverId ? { ...d, pin: cleaned } : d);
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    showToast('PIN updated');
  };

  const resetDriverPin = (driverId) => {
    // Generate a memorable 4-digit temp PIN (avoid leading zeros for clarity)
    const newPin = String(1000 + Math.floor(Math.random() * 9000));
    setState(s => {
      const drivers = s.drivers.map(d => d.id === driverId ? { ...d, pin: newPin } : d);
      const next = { ...s, drivers };
      saveState(next);
      return next;
    });
    setPinResetNotice({ driverId, pin: newPin });
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-950">
      <header className="sticky top-0 z-30 bg-slate-900/95 border-b border-slate-800 backdrop-blur px-4 py-3">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-xs text-slate-400">Admin Control Center</div>
            <div className="font-semibold">FleetShift</div>
          </div>
          <div className="flex items-center gap-2">
            <NetworkBadge online={online} syncing={false} queueLen={queue.length} onToggle={() => setOnline(o => !o)} />
            <button onClick={onLogout} className="p-2 rounded-lg bg-slate-800 text-slate-300">
              <Icon name="LogOut" size={16} />
            </button>
          </div>
        </div>
      </header>

      {toast && (
        <div className="fixed top-16 left-1/2 -translate-x-1/2 z-50 px-4 py-2 rounded-xl text-sm font-medium bg-sky-600 text-white shadow-lg fade-in">
          {toast}
        </div>
      )}

      <main className="flex-1 overflow-y-auto pb-24 px-4 pt-4">
        {tab === 'overview' && (
          <div className="space-y-4 fade-in">
            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'Completed Shifts', value: stats.completed, icon: 'CheckCircle', color: 'text-emerald-400' },
                { label: 'In Progress', value: stats.inProg, icon: 'Loader', color: 'text-amber-400' },
                { label: 'Active Drivers', value: stats.activeDrivers, icon: 'Users', color: 'text-sky-400' },
                { label: 'Total Expenses', value: `${stats.totalExp.toFixed(0)} AED`, icon: 'Wallet', color: 'text-amber-400' },
              ].map(s => (
                <div key={s.label} className="card p-4">
                  <div className={`${s.color} mb-1`}><Icon name={s.icon} size={18} /></div>
                  <div className="text-xl font-bold">{s.value}</div>
                  <div className="text-[11px] text-slate-500">{s.label}</div>
                </div>
              ))}
            </div>

            <div className="card p-4">
              <h3 className="font-semibold text-sm mb-3">Live Upload Feed</h3>
              {allSubmissions.slice(0, 8).length === 0 ? (
                <div className="text-slate-500 text-sm text-center py-6">No submissions yet</div>
              ) : (
                <div className="space-y-2">
                  {allSubmissions.slice(0, 8).map(item => (
                    <div key={item.id} className="flex items-center gap-3 text-sm py-2 border-b border-slate-800 last:border-0">
                      <div className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        item.type === 'trip' ? 'bg-sky-500/15 text-sky-400' :
                        item.type === 'extra' ? 'bg-violet-500/15 text-violet-400' :
                        'bg-amber-500/15 text-amber-400'
                      }`}>
                        <Icon name={item.type === 'trip' ? 'Bus' : item.type === 'extra' ? 'Route' : 'Fuel'} size={14} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="font-medium truncate">{item.driverName}</div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-1 min-w-0">
                          {item.hasReceipt && <Icon name="Paperclip" size={10} className="text-amber-400 shrink-0" />}
                          <span className="truncate">{item.bus} · {item.detail}</span>
                        </div>
                      </div>
                      <div className="text-[10px] text-slate-500 shrink-0">{formatDate(item.createdAt)}</div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

        {tab === 'drivers' && (
          <div className="space-y-3 fade-in">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Driver Roster</h3>
              <button
                onClick={() => setShowAddDriver(true)}
                className="px-3 py-1.5 rounded-lg bg-sky-500 text-white text-sm font-medium flex items-center gap-1"
              >
                <Icon name="Plus" size={14} /> Add
              </button>
            </div>

            {state.drivers.map(d => (
              <div key={d.id} className="card p-4">
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="font-semibold">{d.name}</div>
                    <div className="text-xs font-mono text-slate-400">{d.id}</div>
                    {d.phone && <div className="text-xs text-slate-500 mt-0.5">{d.phone}</div>}
                  </div>
                  <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${
                    d.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
                  }`}>
                    {d.status === 'active' ? 'Active' : 'Locked'}
                  </span>
                </div>
                <div className="mt-3 flex items-center gap-2">
                  <label className="text-xs text-slate-500">Bus:</label>
                  <select
                    value={d.bus}
                    onChange={e => reassignBus(d.id, e.target.value)}
                    className="flex-1 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-sm"
                  >
                    {state.buses.map(b => (
                      <option key={b} value={b}>{b}</option>
                    ))}
                  </select>
                  <button
                    onClick={() => toggleDriver(d.id)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-medium ${
                      d.status === 'active' ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
                    }`}
                  >
                    {d.status === 'active' ? 'Deactivate' : 'Activate'}
                  </button>
                </div>
                <div className="mt-2 flex items-center gap-2 flex-wrap">
                  <label className="text-xs text-slate-500 shrink-0">PIN:</label>
                  <input
                    type="text"
                    inputMode="numeric"
                    defaultValue={d.pin || ''}
                    key={`${d.id}-pin-${d.pin}`}
                    onBlur={e => {
                      const v = e.target.value.replace(/\D/g, '');
                      if (v && v !== d.pin) updateDriverPin(d.id, v);
                    }}
                    onKeyDown={e => {
                      if (e.key === 'Enter') {
                        e.target.blur();
                      }
                    }}
                    className="w-24 bg-slate-800 border border-slate-700 rounded-lg px-2 py-1.5 text-sm font-mono tracking-widest text-center"
                    maxLength={6}
                  />
                  <button
                    type="button"
                    onClick={() => {
                      if (window.confirm(`Reset PIN for ${d.name}? A new temporary PIN will be generated.`)) {
                        resetDriverPin(d.id);
                      }
                    }}
                    className="px-2.5 py-1.5 rounded-lg text-xs font-medium bg-amber-500/15 text-amber-400 border border-amber-500/30 hover:bg-amber-500/25 flex items-center gap-1"
                  >
                    <Icon name="KeyRound" size={12} /> Reset PIN
                  </button>
                </div>
              </div>
            ))}

            {showAddDriver && (
              <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center modal-backdrop p-4">
                <div className="card w-full max-w-md p-5 fade-in">
                  <h3 className="font-semibold mb-4">Onboard New Driver</h3>
                  <div className="space-y-3">
                    <input
                      placeholder="Full name"
                      value={newDriver.name}
                      onChange={e => setNewDriver(f => ({ ...f, name: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                    <input
                      placeholder="Driver ID (e.g. DRV-1005)"
                      value={newDriver.id}
                      onChange={e => setNewDriver(f => ({ ...f, id: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                    <input
                      placeholder="Bus number"
                      value={newDriver.bus}
                      onChange={e => setNewDriver(f => ({ ...f, bus: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                    <input
                      placeholder="PIN (4–6 digits)"
                      value={newDriver.pin}
                      onChange={e => setNewDriver(f => ({ ...f, pin: e.target.value.replace(/\D/g, '').slice(0, 6) }))}
                      inputMode="numeric"
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5 tracking-widest"
                    />
                    <input
                      placeholder="Phone (optional)"
                      value={newDriver.phone}
                      onChange={e => setNewDriver(f => ({ ...f, phone: e.target.value }))}
                      className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2.5"
                    />
                  </div>
                  <div className="flex gap-2 mt-5">
                    <button onClick={() => { setShowAddDriver(false); setNewDriver({ name: '', id: '', bus: '', phone: '', pin: '' }); }} className="flex-1 py-2.5 rounded-xl bg-slate-800 text-sm">Cancel</button>
                    <button onClick={addDriver} className="flex-1 py-2.5 rounded-xl bg-sky-500 text-white text-sm font-semibold">Add Driver</button>
                  </div>
                </div>
              </div>
            )}

            {pinResetNotice && (
              <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center modal-backdrop p-4">
                <div className="card w-full max-w-sm p-6 fade-in text-center">
                  <div className="w-12 h-12 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center mx-auto mb-3">
                    <Icon name="KeyRound" size={24} />
                  </div>
                  <h3 className="font-semibold text-lg mb-1">PIN Reset</h3>
                  <p className="text-sm text-slate-400 mb-4">
                    New temporary PIN for{' '}
                    <span className="text-slate-200 font-medium">
                      {state.drivers.find(x => x.id === pinResetNotice.driverId)?.name || pinResetNotice.driverId}
                    </span>
                  </p>
                  <div className="bg-slate-800 border border-slate-700 rounded-xl py-4 mb-4">
                    <div className="text-[11px] text-slate-500 uppercase tracking-wide mb-1">Share this PIN with the driver</div>
                    <div className="text-3xl font-mono font-bold tracking-[0.3em] text-amber-400">{pinResetNotice.pin}</div>
                  </div>
                  <p className="text-[11px] text-slate-500 mb-4">Driver should change it after login if needed (admin can edit anytime).</p>
                  <button
                    onClick={() => setPinResetNotice(null)}
                    className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
                  >
                    Done
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {tab === 'audit' && (
          <div className="space-y-3 fade-in">
            <h3 className="font-semibold">Master Audit Trail</h3>
            <div className="card overflow-hidden">
              <div className="table-wrap">
                <table className="text-sm">
                  <thead>
                    <tr className="bg-slate-900">
                      <th>Time</th>
                      <th>Type</th>
                      <th>Driver</th>
                      <th>Bus</th>
                      <th>Detail</th>
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {allSubmissions.length === 0 && (
                      <tr><td colSpan={6} className="text-center text-slate-500 py-8">No records</td></tr>
                    )}
                    {allSubmissions.map(item => (
                      <tr key={item.id}>
                        <td className="text-xs text-slate-400">{formatDate(item.createdAt)}</td>
                        <td className="capitalize">{item.type}</td>
                        <td>{item.driverName}</td>
                        <td className="font-mono text-xs">{item.bus}</td>
                        <td>{item.detail}</td>
                        <td>
                          <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                            item.status === 'completed' || item.status === 'logged' ? 'bg-emerald-500/15 text-emerald-400' :
                            item.status === 'in_progress' ? 'bg-amber-500/15 text-amber-400' :
                            'bg-slate-700 text-slate-300'
                          }`}>{item.status}</span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {tab === 'buses' && (
          <div className="space-y-3 fade-in">
            <h3 className="font-semibold">Fleet Buses</h3>
            <div className="grid gap-2">
              {state.buses.map(b => {
                const assigned = state.drivers.filter(d => d.bus === b);
                return (
                  <div key={b} className="card p-4 flex items-center justify-between">
                    <div>
                      <div className="font-mono font-semibold">{b}</div>
                      <div className="text-xs text-slate-500">
                        {assigned.length ? assigned.map(d => d.name).join(', ') : 'Unassigned'}
                      </div>
                    </div>
                    <Icon name="Bus" size={20} className="text-sky-400" />
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </main>

      <nav className="fixed bottom-0 inset-x-0 bg-slate-900/95 border-t border-slate-800 backdrop-blur safe-bottom z-30">
        <div className="flex justify-around py-2">
          {[
            { id: 'overview', icon: 'LayoutDashboard', label: 'Overview' },
            { id: 'drivers', icon: 'Users', label: 'Drivers' },
            { id: 'audit', icon: 'ScrollText', label: 'Audit' },
            { id: 'buses', icon: 'Bus', label: 'Buses' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setTab(item.id)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1.5 rounded-lg text-[10px] font-medium ${
                tab === item.id ? 'text-sky-400' : 'text-slate-500'
              }`}
            >
              <Icon name={item.icon} size={20} />
              {item.label}
            </button>
          ))}
        </div>
      </nav>
    </div>
  );
}

// ─────────────────────────────────────────────
// Login / Role Select
// ─────────────────────────────────────────────
function LoginScreen({ state, onDriverLogin, onAdminLogin, forceDriver = false, forceAdmin = false }) {
  const initialMode = forceDriver ? 'driver' : forceAdmin ? 'admin' : null;
  const [mode, setMode] = useState(initialMode); // null | driver | admin
  const [selectedDriver, setSelectedDriver] = useState('');
  const [driverPin, setDriverPin] = useState('');
  const [adminPass, setAdminPass] = useState('');
  const [error, setError] = useState('');
  const [showForgotPin, setShowForgotPin] = useState(false);
  const pinRef = useRef(null);

  const activeDrivers = (state.drivers || []).filter(d => d.status === 'active');

  const tryAdmin = () => {
    if (adminPass === ADMIN_PASS) {
      onAdminLogin();
    } else {
      setError('Incorrect passcode');
    }
  };

  const tryDriver = () => {
    const d = state.drivers.find(x => x.id === selectedDriver);
    if (!d || d.status !== 'active') {
      setError('Select an active driver');
      return;
    }
    const expected = String(d.pin || '').trim();
    const entered = String(driverPin || '').trim();
    if (!entered) {
      setError('Enter your PIN');
      return;
    }
    if (entered !== expected) {
      setError('Incorrect PIN');
      setDriverPin('');
      if (pinRef.current) pinRef.current.focus();
      return;
    }
    setError('');
    onDriverLogin(d);
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <div className="text-center mb-8">
        <div className="text-5xl mb-3">🚌</div>
        <h1 className="text-2xl font-bold tracking-tight">FleetShift</h1>
        <p className="text-slate-400 text-sm mt-1">
          {forceDriver ? 'Driver Portal · AVA Transport' :
           forceAdmin ? 'Admin Control Center · AVA Transport' :
           'AVA Transport · Trip & Expense System'}
        </p>
      </div>

      {!mode && (
        <div className="w-full max-w-sm space-y-3 fade-in">
          <button
            onClick={() => setMode('driver')}
            className="w-full card card-hover p-5 text-left flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-xl bg-sky-500/20 flex items-center justify-center text-sky-400">
              <Icon name="User" size={24} />
            </div>
            <div>
              <div className="font-semibold">Driver Portal</div>
              <div className="text-xs text-slate-400">Log shifts, extras & expenses</div>
            </div>
          </button>
          <button
            onClick={() => setMode('admin')}
            className="w-full card card-hover p-5 text-left flex items-center gap-4"
          >
            <div className="w-12 h-12 rounded-xl bg-violet-500/20 flex items-center justify-center text-violet-400">
              <Icon name="Shield" size={24} />
            </div>
            <div>
              <div className="font-semibold">Admin Control Center</div>
              <div className="text-xs text-slate-400">Roster, audit & fleet overview</div>
            </div>
          </button>
        </div>
      )}

      {mode === 'driver' && (
        <div className="w-full max-w-sm card p-6 fade-in">
          {!forceDriver && (
            <button onClick={() => { setMode(null); setError(''); setDriverPin(''); }} className="text-xs text-slate-400 mb-4 flex items-center gap-1">
              <Icon name="ArrowLeft" size={14} /> Back
            </button>
          )}
          <h2 className="font-semibold mb-1">Driver Login</h2>
          <p className="text-xs text-slate-500 mb-4">Select your profile and enter your PIN</p>
          <label className="text-xs text-slate-400 block mb-1">Driver</label>
          <select
            value={selectedDriver}
            onChange={e => { setSelectedDriver(e.target.value); setError(''); setDriverPin(''); }}
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 mb-4"
          >
            <option value="">— Choose driver —</option>
            {activeDrivers.map(d => (
              <option key={d.id} value={d.id}>{d.name} · {d.bus}</option>
            ))}
          </select>
          <label className="text-xs text-slate-400 block mb-1">PIN</label>
          <input
            ref={pinRef}
            type="password"
            inputMode="numeric"
            pattern="[0-9]*"
            maxLength={6}
            value={driverPin}
            onChange={e => { setDriverPin(e.target.value.replace(/\D/g, '')); setError(''); }}
            onKeyDown={e => e.key === 'Enter' && tryDriver()}
            placeholder="••••"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 mb-4 text-center text-xl tracking-[0.4em] font-semibold"
            autoComplete="off"
          />
          {error && <div className="text-red-400 text-xs mb-3 flex items-center gap-1"><Icon name="AlertCircle" size={12} /> {error}</div>}
          <button
            onClick={tryDriver}
            disabled={!selectedDriver}
            className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold"
          >
            Unlock Portal
          </button>
          <button
            type="button"
            onClick={() => setShowForgotPin(true)}
            className="w-full mt-3 text-xs text-slate-400 hover:text-sky-400 py-1"
          >
            Forgot PIN?
          </button>
          <p className="text-[10px] text-slate-600 text-center mt-1">Demo PINs match last 4 of ID (e.g. 1001)</p>
        </div>
      )}

      {showForgotPin && (
        <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center modal-backdrop p-4">
          <div className="card w-full max-w-sm p-6 fade-in">
            <div className="w-12 h-12 rounded-full bg-sky-500/20 text-sky-400 flex items-center justify-center mx-auto mb-3">
              <Icon name="KeyRound" size={22} />
            </div>
            <h3 className="font-semibold text-center text-lg mb-2">Forgot your PIN?</h3>
            <p className="text-sm text-slate-400 text-center mb-4 leading-relaxed">
              For security, PINs can only be reset by an administrator.
              Contact your supervisor or fleet admin and ask them to use
              <span className="text-slate-200 font-medium"> Reset PIN </span>
              on your profile in the Admin Control Center.
            </p>
            <div className="bg-slate-800/80 border border-slate-700 rounded-xl p-3 mb-4 text-xs text-slate-400">
              <div className="font-medium text-slate-300 mb-1">What the admin will do</div>
              <ol className="list-decimal list-inside space-y-1">
                <li>Open Admin → Drivers</li>
                <li>Find your name and tap <strong className="text-amber-400">Reset PIN</strong></li>
                <li>Share the new temporary PIN with you</li>
              </ol>
            </div>
            <button
              onClick={() => setShowForgotPin(false)}
              className="w-full py-3 rounded-xl bg-sky-500 hover:bg-sky-400 text-white font-semibold"
            >
              Got it
            </button>
          </div>
        </div>
      )}

      {mode === 'admin' && (
        <div className="w-full max-w-sm card p-6 fade-in">
          {!forceAdmin && (
            <button onClick={() => { setMode(null); setError(''); setAdminPass(''); }} className="text-xs text-slate-400 mb-4 flex items-center gap-1">
              <Icon name="ArrowLeft" size={14} /> Back
            </button>
          )}
          <h2 className="font-semibold mb-4">Admin Passcode</h2>
          <input
            type="password"
            value={adminPass}
            onChange={e => setAdminPass(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && tryAdmin()}
            placeholder="Enter passcode"
            className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-3 mb-4 text-center tracking-widest"
          />
          {error && <div className="text-red-400 text-xs mb-3">{error}</div>}
          <button
            onClick={tryAdmin}
            className="w-full py-3 rounded-xl bg-violet-500 hover:bg-violet-400 text-white font-semibold"
          >
            Unlock Admin
          </button>
          <p className="text-[10px] text-slate-600 text-center mt-3">Default: admin123</p>
        </div>
      )}
    </div>
  );
}

// ─────────────────────────────────────────────
// Root App
// ─────────────────────────────────────────────
function App() {
  const forceDriver = typeof window !== 'undefined' && window.FLEETSHIFT_MODE === 'driver';
  const forceAdmin = typeof window !== 'undefined' && window.FLEETSHIFT_MODE === 'admin';
  const [state, setState] = useState(loadState);
  const [role, setRole] = useState(null); // null | 'driver' | 'admin'
  const [currentDriver, setCurrentDriver] = useState(null);
  const [online, setOnline] = useState(true);
  const [queue, setQueue] = useState(loadQueue);

  // Persist state
  useEffect(() => {
    saveState(state);
  }, [state]);

  const logout = () => {
    setRole(null);
    setCurrentDriver(null);
  };

  if (!role) {
    return (
      <LoginScreen
        state={state}
        forceDriver={forceDriver}
        forceAdmin={forceAdmin}
        onDriverLogin={(d) => { setCurrentDriver(d); setRole('driver'); }}
        onAdminLogin={() => setRole('admin')}
      />
    );
  }

  if (role === 'driver' && currentDriver) {
    // Always use latest driver data from state
    const liveDriver = state.drivers.find(d => d.id === currentDriver.id) || currentDriver;
    return (
      <DriverPortal
        state={state}
        setState={setState}
        driver={liveDriver}
        online={online}
        setOnline={setOnline}
        queue={queue}
        setQueue={setQueue}
        onLogout={logout}
      />
    );
  }

  if (role === 'admin') {
    return (
      <AdminPortal
        state={state}
        setState={setState}
        online={online}
        setOnline={setOnline}
        queue={queue}
        setQueue={setQueue}
        onLogout={logout}
      />
    );
  }

  return null;
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
